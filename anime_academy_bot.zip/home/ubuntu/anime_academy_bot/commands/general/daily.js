const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { getUser, updateUser } = require("../../utils/userDataManager");
const { generateCardImage } = require("../../utils/cardGenerator"); // استيراد مولد صور الكروت

const cardsFilePath = path.join(__dirname, "../../data/cards.json");

// دالة للتحقق مما إذا كان اليوم قد مر منذ تاريخ معين
function isAnotherDay(timestamp) {
    if (!timestamp) return true;
    const lastClaim = new Date(timestamp);
    const now = new Date();
    return now.getFullYear() > lastClaim.getFullYear()
           || now.getMonth() > lastClaim.getMonth()
           || now.getDate() > lastClaim.getDate();
}

// دالة لاختيار كرت عشوائي بناءً على الندرة
async function getRandomCard() {
    try {
        const cardsData = await fs.readJson(cardsFilePath);
        if (!cardsData || !cardsData.cards || !cardsData.rarities) {
            throw new Error("ملف بيانات الكروت غير صالح.");
        }

        const rarities = cardsData.rarities;
        const cards = cardsData.cards;
        const totalDropRate = Object.values(rarities).reduce((sum, r) => sum + r.dropRate, 0);

        let random = Math.random() * totalDropRate;
        let selectedRarityKey = null;

        for (const rarityKey in rarities) {
            if (random < rarities[rarityKey].dropRate) {
                selectedRarityKey = rarityKey;
                break;
            }
            random -= rarities[rarityKey].dropRate;
        }

        if (!selectedRarityKey) {
            selectedRarityKey = "common"; // افتراضي
        }

        const cardsOfSelectedRarity = cards.filter((card) => card.rarity === selectedRarityKey);
        if (cardsOfSelectedRarity.length === 0) {
            const commonCards = cards.filter((card) => card.rarity === "common");
            if (commonCards.length === 0) return null;
            const chosenCard = commonCards[Math.floor(Math.random() * commonCards.length)];
            return { ...chosenCard, rarityData: rarities.common }; // إرجاع بيانات الندرة مع الكرت
        }

        const chosenCard = cardsOfSelectedRarity[Math.floor(Math.random() * cardsOfSelectedRarity.length)];
        return { ...chosenCard, rarityData: rarities[selectedRarityKey] }; // إرجاع بيانات الندرة مع الكرت
    } catch (error) {
        console.error("خطأ في اختيار كرت عشوائي:", error);
        return null;
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("daily")
        .setDescription("احصل على مكافأتك اليومية من نقاط الخبرة وفرصة الحصول على كرت!"),
    async execute(interaction) {
        const userId = interaction.user.id;
        const username = interaction.user.username;
        await interaction.deferReply({ ephemeral: true });

        try {
            const userData = await getUser(userId, username);

            if (!userData) {
                await interaction.editReply({ content: "حدث خطأ أثناء جلب بياناتك. حاول مرة أخرى." });
                return;
            }

            if (userData.lastDailyClaim && !isAnotherDay(userData.lastDailyClaim)) {
                await interaction.editReply({ content: "لقد حصلت بالفعل على مكافأتك اليومية. عد غداً!" });
                return;
            }

            const dailyReward = 100;
            const newXP = (userData.xp || 0) + dailyReward;

            const awardedCard = await getRandomCard();
            let cardMessage = "";
            const updatedCollection = userData.collection || [];
            let cardAttachment = null;
            let cardEmbed = null;

            if (awardedCard) {
                const cardExists = updatedCollection.find((c) => c.id === awardedCard.id);
                if (cardExists) {
                    cardExists.count = (cardExists.count || 1) + 1;
                } else {
                    updatedCollection.push({ id: awardedCard.id, count: 1 });
                }

                cardMessage = `\n🎁 لقد حصلت أيضاً على كرت: **${awardedCard.name}** [${awardedCard.rarityData?.name || awardedCard.rarity}]!`;

                // توليد صورة الكرت
                try {
                    const cardImageBuffer = await generateCardImage(awardedCard, awardedCard.rarityData);
                    cardAttachment = new AttachmentBuilder(cardImageBuffer, { name: `daily-card-${awardedCard.id}.png` });
                    cardEmbed = new EmbedBuilder()
                        .setColor(awardedCard.rarityData?.color || 0xAAAAAA)
                        .setTitle("🎉 كرت جديد! 🎉")
                        .setDescription(`تهانينا! لقد حصلت على كرت **${awardedCard.name}**!`)
                        .setImage(`attachment://daily-card-${awardedCard.id}.png`);
                } catch (imgError) {
                    console.error(`خطأ في توليد صورة الكرت اليومي ${awardedCard.id}:`, imgError);
                    cardMessage += " (لم نتمكن من عرض صورة الكرت حالياً)";
                }
            }

            const updateResult = await updateUser(userId, {
                xp: newXP,
                lastDailyClaim: new Date().toISOString(),
                collection: updatedCollection,
            });

            if (updateResult) {
                const replyPayload = {
                    content: `🎉 لقد حصلت على ${dailyReward} نقطة خبرة كمكافأة يومية! رصيدك الحالي هو ${newXP} نقطة.${cardMessage}`,
                    embeds: cardEmbed ? [cardEmbed] : [],
                    files: cardAttachment ? [cardAttachment] : [],
                    ephemeral: true,
                };
                await interaction.editReply(replyPayload);
            } else {
                await interaction.editReply({ content: "حدث خطأ أثناء تحديث بياناتك. حاول مرة أخرى.", ephemeral: true });
            }
        } catch (error) {
            console.error("خطأ في أمر /daily:", error);
            await interaction.editReply({ content: "حدث خطأ أثناء محاولة الحصول على المكافأة اليومية. الرجاء المحاولة مرة أخرى لاحقاً.", ephemeral: true });
        }
    },
};
