const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const axios = require("axios");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("search_anime")
        .setDescription("ابحث عن معلومات أنمي محدد.") // الشرح بالعربي
        .addStringOption((option) => option.setName("name")
            .setDescription("اسم الأنمي الذي تبحث عنه") // الشرح بالعربي
            .setRequired(true)),
    async execute(interaction) {
        const animeName = interaction.options.getString("name");
        await interaction.deferReply(); // تأجيل الرد لإتاحة الوقت للبحث

        try {
            const response = await axios.get(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(animeName)}&limit=1`);

            if (response.data.data.length === 0) {
                await interaction.editReply(`لم أتمكن من العثور على أنمي باسم "${animeName}". الرجاء التأكد من الاسم والمحاولة مرة أخرى.`);
                return;
            }

            const anime = response.data.data[0];

            // بناء رسالة Embed لعرض المعلومات
            const embed = new EmbedBuilder()
                .setColor(0x0099FF) // لون أزرق مبدئي
                .setTitle(`${anime.title_japanese} | ${anime.title_english || anime.title}`)
                .setURL(anime.url)
                .setDescription(anime.synopsis ? `${anime.synopsis.substring(0, 250)}...` : "لا يوجد وصف متاح.")
                .addFields(
                    { name: "النوع", value: anime.type || "غير معروف", inline: true },
                    { name: "الحالة", value: anime.status || "غير معروف", inline: true },
                    { name: "التقييم", value: anime.score ? `${anime.score} ⭐` : "غير مقيم", inline: true },
                    { name: "عدد الحلقات", value: anime.episodes ? anime.episodes.toString() : "غير معروف", inline: true },
                    { name: "التصنيف", value: anime.rating || "غير معروف", inline: true },
                    { name: "الموسم", value: `${anime.season || "غير معروف"} ${anime.year || ""}`, inline: true },
                )
                .setImage(anime.images?.jpg?.large_image_url || null)
                .setTimestamp()
                .setFooter({ text: "المعلومات مقدمة بواسطة Jikan API" });

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error("خطأ في البحث عن الأنمي:", error.response ? error.response.status : error.message);
            // التحقق من خطأ تجاوز الحد
            if (error.response && error.response.status === 429) {
                await interaction.editReply("لقد وصلنا إلى حد طلبات البحث في الوقت الحالي 😥. الرجاء المحاولة مرة أخرى بعد قليل.");
            } else {
                await interaction.editReply("حدث خطأ أثناء البحث عن الأنمي. الرجاء المحاولة مرة أخرى لاحقاً.");
            }
        }
    },
};
