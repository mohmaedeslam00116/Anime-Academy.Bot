const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const axios = require("axios");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("search_manga")
        .setDescription("ابحث عن معلومات مانجا محددة.") // الشرح بالعربي
        .addStringOption((option) => option.setName("name")
            .setDescription("اسم المانجا التي تبحث عنها") // الشرح بالعربي
            .setRequired(true)),
    async execute(interaction) {
        const mangaName = interaction.options.getString("name");
        await interaction.deferReply(); // تأجيل الرد لإتاحة الوقت للبحث

        try {
            const response = await axios.get(`https://api.jikan.moe/v4/manga?q=${encodeURIComponent(mangaName)}&limit=1`);

            if (response.data.data.length === 0) {
                await interaction.editReply(`لم أتمكن من العثور على مانجا باسم "${mangaName}". الرجاء التأكد من الاسم والمحاولة مرة أخرى.`);
                return;
            }

            const manga = response.data.data[0];

            // بناء رسالة Embed لعرض المعلومات
            const embed = new EmbedBuilder()
                .setColor(0x4E9F3D) // لون أخضر مبدئي
                .setTitle(`${manga.title_japanese} | ${manga.title_english || manga.title}`)
                .setURL(manga.url)
                .setDescription(manga.synopsis ? `${manga.synopsis.substring(0, 250)}...` : "لا يوجد وصف متاح.")
                .addFields(
                    { name: "النوع", value: manga.type || "غير معروف", inline: true },
                    { name: "الحالة", value: manga.status || "غير معروف", inline: true },
                    { name: "التقييم", value: manga.score ? `${manga.score} ⭐` : "غير مقيم", inline: true },
                    { name: "عدد الفصول", value: manga.chapters ? manga.chapters.toString() : "غير معروف", inline: true },
                    { name: "عدد المجلدات", value: manga.volumes ? manga.volumes.toString() : "غير معروف", inline: true },
                    { name: "تاريخ النشر", value: manga.published?.string || "غير معروف", inline: true },
                )
                .setImage(manga.images?.jpg?.large_image_url || null)
                .setTimestamp()
                .setFooter({ text: "المعلومات مقدمة بواسطة Jikan API" });

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error("خطأ في البحث عن المانجا:", error.response ? error.response.status : error.message);
            // التحقق من خطأ تجاوز الحد
            if (error.response && error.response.status === 429) {
                await interaction.editReply("لقد وصلنا إلى حد طلبات البحث في الوقت الحالي 😥. الرجاء المحاولة مرة أخرى بعد قليل.");
            } else {
                await interaction.editReply("حدث خطأ أثناء البحث عن المانجا. الرجاء المحاولة مرة أخرى لاحقاً.");
            }
        }
    },
};
