const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");

const shopFilePath = path.join(__dirname, "../../data/shop.json");
const ITEMS_PER_PAGE = 5;

// دالة لتحميل بيانات المتجر
async function loadShopData() {
    try {
        const data = await fs.readJson(shopFilePath);
        return data.items || [];
    } catch (error) {
        console.error("خطأ في تحميل بيانات المتجر:", error);
        return [];
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("shop")
        .setDescription("عرض العناصر المتاحة للشراء في المتجر."),
    async execute(interaction) {
        await interaction.deferReply();

        try {
            const shopItems = await loadShopData();

            if (shopItems.length === 0) {
                await interaction.editReply("المتجر فارغ حالياً. عد لاحقاً!");
                return;
            }

            const totalPages = Math.ceil(shopItems.length / ITEMS_PER_PAGE);
            let currentPage = 0;

            // دالة لإنشاء Embed للصفحة الحالية
            const generatePageEmbed = (page) => {
                const start = page * ITEMS_PER_PAGE;
                const end = start + ITEMS_PER_PAGE;
                const currentItems = shopItems.slice(start, end);

                const embed = new EmbedBuilder()
                    .setColor(0x2ECC71) // لون أخضر للمتجر
                    .setTitle(`🛒 متجر أكاديمية عالم الأنمي (صفحة ${page + 1}/${totalPages})`)
                    .setDescription("استخدم أمر `/buy [item_id]` لشراء عنصر.")
                    .setTimestamp();

                currentItems.forEach((item) => {
                    embed.addFields({
                        name: `🛍️ ${item.name} (ID: ${item.id})`,
                        value: `**الوصف:** ${item.description}\n**السعر:** ${item.cost} نقطة خبرة ✨`,
                        inline: false,
                    });
                });

                return embed;
            };

            // دالة لإنشاء أزرار التنقل
            const generateButtons = (page) => {
                return new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("prev_shop_page")
                            .setLabel("◀️ السابق")
                            .setStyle(ButtonStyle.Success)
                            .setDisabled(page === 0),
                        new ButtonBuilder()
                            .setCustomId("next_shop_page")
                            .setLabel("التالي ▶️")
                            .setStyle(ButtonStyle.Success)
                            .setDisabled(page >= totalPages - 1),
                    );
            };

            const initialEmbed = generatePageEmbed(currentPage);
            const initialButtons = generateButtons(currentPage);

            const reply = await interaction.editReply({
                embeds: [initialEmbed],
                components: totalPages > 1 ? [initialButtons] : [],
            });

            if (totalPages <= 1) return;

            // مجمع الأزرار للتنقل
            const collector = reply.createMessageComponentCollector({
                componentType: ComponentType.Button,
                time: 120000, // دقيقتان
            });

            collector.on("collect", async (i) => {
                if (i.user.id !== interaction.user.id) {
                    await i.reply({ content: "أنت لا تستطيع التحكم في هذه القائمة.", ephemeral: true });
                    return;
                }

                if (i.customId === "prev_shop_page") {
                    currentPage--;
                } else if (i.customId === "next_shop_page") {
                    currentPage++;
                }

                const updatedEmbed = generatePageEmbed(currentPage);
                const updatedButtons = generateButtons(currentPage);
                await i.update({ embeds: [updatedEmbed], components: [updatedButtons] });
            });

            collector.on("end", async () => {
                const finalEmbed = generatePageEmbed(currentPage);
                const disabledButtons = ActionRowBuilder.from(initialButtons);
                disabledButtons.components.forEach((button) => button.setDisabled(true));
                await interaction.editReply({ embeds: [finalEmbed], components: [disabledButtons] }).catch(console.error);
            });
        } catch (error) {
            console.error("خطأ في أمر /shop:", error);
            await interaction.editReply("حدث خطأ أثناء محاولة عرض المتجر.");
        }
    },
};
