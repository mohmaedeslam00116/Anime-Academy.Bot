const { SlashCommandBuilder, AttachmentBuilder } = require("discord.js");
const { getUser } = require("../../utils/userDataManager");
const { createProfileCard } = require("../../utils/profileCardGenerator"); // سنقوم بإنشاء هذا الملف لاحقاً

module.exports = {
    data: new SlashCommandBuilder()
        .setName("profile")
        .setDescription("عرض ملفك الشخصي في أكاديمية عالم الأنمي.") // الشرح بالعربي
        .addUserOption((option) => option.setName("user")
            .setDescription("المستخدم الذي تريد عرض ملفه الشخصي (اختياري)") // الشرح بالعربي
            .setRequired(false)),
    async execute(interaction) {
        const targetUser = interaction.options.getUser("user") || interaction.user;
        await interaction.deferReply();

        try {
            // الحصول على بيانات المستخدم أو إنشائها إذا لم تكن موجودة
            const userData = await getUser(targetUser.id, targetUser.username);

            if (!userData) {
                await interaction.editReply("حدث خطأ أثناء جلب بيانات المستخدم.");
                return;
            }

            // إنشاء بطاقة الملف الشخصي باستخدام Canvas
            const profileImageBuffer = await createProfileCard(targetUser, userData);

            if (!profileImageBuffer) {
                await interaction.editReply("حدث خطأ أثناء إنشاء بطاقة الملف الشخصي.");
                return;
            }

            const attachment = new AttachmentBuilder(profileImageBuffer, { name: `profile-${targetUser.id}.png` });

            await interaction.editReply({ files: [attachment] });
        } catch (error) {
            console.error("خطأ في أمر /profile:", error);
            await interaction.editReply("حدث خطأ أثناء عرض الملف الشخصي. الرجاء المحاولة مرة أخرى لاحقاً.");
        }
    },
};
