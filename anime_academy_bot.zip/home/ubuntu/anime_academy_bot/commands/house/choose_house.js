const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ComponentType } = require("discord.js");
const { getUser, updateUser, loadHousesData } = require("../../utils/userDataManager");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("choose_house")
        .setDescription("اختر بيتك في أكاديمية عالم الأنمي!"), // الشرح بالعربي
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const userId = interaction.user.id;
        const username = interaction.user.username;

        try {
            const userData = await getUser(userId, username);

            // التحقق مما إذا كان المستخدم لديه بيت بالفعل
            if (userData.house) {
                const housesData = await loadHousesData();
                const currentHouseName = housesData[userData.house]?.name || "بيت غير معروف";
                await interaction.editReply(`أنت تنتمي بالفعل إلى **${currentHouseName}**! لا يمكنك تغيير بيتك حالياً.`);
                return;
            }

            // جلب بيانات البيوت المتاحة
            const housesData = await loadHousesData();
            const availableHouses = Object.entries(housesData).map(([id, data]) => ({
                label: data.name, // اسم البيت للعرض
                description: data.description.substring(0, 100), // وصف مختصر
                value: id, // ID البيت كقيمة
                emoji: data.emoji, // إيموجي البيت
            }));

            if (availableHouses.length === 0) {
                await interaction.editReply("عذراً، لا توجد بيوت متاحة للاختيار حالياً.");
                return;
            }

            // إنشاء قائمة الاختيار المنسدلة
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId("house_select")
                .setPlaceholder("اختر بيتك الذي تفضله...")
                .addOptions(availableHouses.map((house) => ({
                    label: `${house.emoji || ""} ${house.label}`.trim(),
                    description: house.description,
                    value: house.value,
                })));

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const embed = new EmbedBuilder()
                .setColor(0x3498DB)
                .setTitle("🏰 اختر بيتك!")
                .setDescription("كل بيت يمثل قيماً وصفات مختلفة. اختر البيت الذي تشعر أنه يمثلك أكثر للانضمام إليه وبدء رحلتك في الأكاديمية!")
                .setFooter({ text: "يمكنك اختيار بيتك مرة واحدة فقط." });

            const reply = await interaction.editReply({ embeds: [embed], components: [row], ephemeral: true });

            // جمع ردود قائمة الاختيار
            const collector = reply.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
                time: 60000, // دقيقة واحدة للاختيار
            });

            collector.on("collect", async (i) => {
                if (i.user.id !== userId) {
                    await i.reply({ content: "هذا الاختيار مخصص للمستخدم الأصلي فقط.", ephemeral: true });
                    return;
                }

                const selectedHouseId = i.values[0];
                const selectedHouseData = housesData[selectedHouseId];

                if (!selectedHouseData) {
                    await i.update({ content: "حدث خطأ أثناء اختيار البيت. حاول مرة أخرى.", embeds: [], components: [] });
                    return;
                }

                // تحديث بيانات المستخدم بالبيت المختار
                const updateSuccess = await updateUser(userId, { house: selectedHouseId });

                if (updateSuccess) {
                    const confirmationEmbed = new EmbedBuilder()
                        .setColor(selectedHouseData.color || 0x00FF00)
                        .setTitle(`🎉 مرحباً بك في ${selectedHouseData.emoji || ""} ${selectedHouseData.name}! 🎉`)
                        .setDescription(`لقد انضممت بنجاح إلى بيت الشجعان والمحاربين (أو أي وصف آخر للبيت). حظاً موفقاً في رحلتك الأكاديمية!
يمكنك الآن استخدام أمر 
/profile
 لعرض بيتك الجديد.`)
                        .setThumbnail(selectedHouseData.iconUrl || null); // إضافة أيقونة البيت إذا وجدت

                    await i.update({ embeds: [confirmationEmbed], components: [] }); // إزالة قائمة الاختيار بعد الاختيار
                    console.log(`المستخدم ${username} (${userId}) اختار الانضمام إلى بيت ${selectedHouseData.name} (${selectedHouseId})`);
                } else {
                    await i.update({ content: "حدث خطأ فادح أثناء تحديث بياناتك. الرجاء إبلاغ المسؤولين.", embeds: [], components: [] });
                }
                collector.stop();
            });

            collector.on("end", async (collected) => {
                if (collected.size === 0) {
                    // إذا انتهى الوقت ولم يتم الاختيار
                    await interaction.editReply({ content: "انتهى وقت الاختيار. يمكنك استخدام الأمر `/choose_house` مرة أخرى عندما تكون مستعداً.", embeds: [], components: [] }).catch(console.error);
                }
            });
        } catch (error) {
            console.error("خطأ في أمر /choose_house:", error);
            await interaction.editReply({ content: "حدث خطأ أثناء محاولة تنفيذ الأمر. الرجاء المحاولة مرة أخرى لاحقاً.", embeds: [], components: [] });
        }
    },
};
