const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");

const eventsFilePath = path.join(__dirname, "../../data/events.json");

// Helper function to load event data
async function loadEventsData() {
    try {
        return await fs.readJson(eventsFilePath);
    } catch (error) {
        if (error.code === "ENOENT") {
            // If file doesn't exist, create it with default structure
            await fs.writeJson(eventsFilePath, { activeEvents: [] }, { spaces: 2 });
            return { activeEvents: [] };
        }
        console.error("Error loading events file:", error);
        return { activeEvents: [] }; // Return default on other errors
    }
}

// Helper function to save event data
async function saveEventsData(data) {
    try {
        await fs.writeJson(eventsFilePath, data, { spaces: 2 });
    } catch (error) {
        console.error("Error saving events file:", error);
        // Consider throwing error or notifying admin if saving fails
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("manage_event")
        .setDescription("Manage active bot events (Admin Only)")
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
        .addSubcommand((subcommand) => subcommand
            .setName("add")
            .setDescription("Add a new event")
            .addStringOption((option) => option.setName("id").setDescription("Unique event ID (e.g., xp_boost_weekend)").setRequired(true))
            .addStringOption((option) => option.setName("name").setDescription("Display name for the event").setRequired(true))
            .addStringOption((option) => option.setName("description").setDescription("Description of the event").setRequired(true))
            .addStringOption((option) => option.setName("type").setDescription("Event type (xp_multiplier or card_drop_boost)").setRequired(true).addChoices(
                { name: "XP Multiplier (xp_multiplier)", value: "xp_multiplier" },
                // eslint-disable-next-line max-len
                { name: "Card Drop Boost (card_drop_boost)", value: "card_drop_boost" },
            ))
            .addStringOption((option) => option.setName("start_time").setDescription("Start time (ISO format: YYYY-MM-DDTHH:mm:ssZ)").setRequired(true))
            .addStringOption((option) => option.setName("end_time").setDescription("End time (ISO format: YYYY-MM-DDTHH:mm:ssZ)").setRequired(true))
            .addNumberOption((option) => option.setName("multiplier").setDescription("Multiplier value (for xp_multiplier type)").setRequired(false))
            // eslint-disable-next-line max-len
            .addStringOption((option) => option.setName("rarity_boost").setDescription("Rarity boost JSON (e.g., {\"rare\": 2}) for card_drop_boost").setRequired(false)))
        .addSubcommand((subcommand) => subcommand
            .setName("remove")
            .setDescription("Remove an event by its ID")
            .addStringOption((option) => option.setName("id").setDescription("ID of the event to remove").setRequired(true)))
        .addSubcommand((subcommand) => subcommand
            .setName("list")
            .setDescription("List all scheduled events (active and inactive)")),
    async execute(interaction) {
        // Double-check admin permissions
        if (!interaction.memberPermissions.has(PermissionsBitField.Flags.Administrator)) {
            return interaction.reply({ content: "You do not have permission to use this command.", ephemeral: true });
        }

        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply({ ephemeral: true });

        try {
            const eventsData = await loadEventsData();

            if (subcommand === "add") {
                const id = interaction.options.getString("id");
                const name = interaction.options.getString("name");
                const description = interaction.options.getString("description");
                const type = interaction.options.getString("type");
                const startTimeStr = interaction.options.getString("start_time");
                const endTimeStr = interaction.options.getString("end_time");
                const multiplier = interaction.options.getNumber("multiplier");
                const rarityBoostStr = interaction.options.getString("rarity_boost");

                // Validate ID uniqueness
                if (eventsData.activeEvents.some((event) => event.id === id)) {
                    return interaction.editReply(`Error: Event ID '${id}' is already in use.`);
                }

                // Validate dates
                const startTime = new Date(startTimeStr);
                const endTime = new Date(endTimeStr);
                if (Number.isNaN(startTime.getTime()) || Number.isNaN(endTime.getTime())) {
                    return interaction.editReply("Error: Invalid start or end time format. Use ISO 8601 (YYYY-MM-DDTHH:mm:ssZ).");
                }
                if (startTime >= endTime) {
                    return interaction.editReply("Error: Start time must be before end time.");
                }

                const newEvent = {
                    id,
                    name,
                    description,
                    type,
                    startTime: startTime.toISOString(), // Store as ISO string
                    endTime: endTime.toISOString(), // Store as ISO string
                };

                // Validate type-specific options
                if (type === "xp_multiplier") {
                    if (multiplier === null || multiplier <= 0) {
                        return interaction.editReply("Error: Multiplier must be a positive number for xp_multiplier events.");
                    }
                    newEvent.multiplier = multiplier;
                } else if (type === "card_drop_boost") {
                    if (!rarityBoostStr) {
                        return interaction.editReply("Error: Rarity boost JSON is required for card_drop_boost events.");
                    }
                    try {
                        newEvent.rarityBoost = JSON.parse(rarityBoostStr);
                        // Basic validation of boost structure (optional but recommended)
                        if (typeof newEvent.rarityBoost !== "object" || newEvent.rarityBoost === null) {
                            throw new Error("rarityBoost must be a JSON object.");
                        }
                        for (const key in newEvent.rarityBoost) {
                            if (typeof newEvent.rarityBoost[key] !== "number" || newEvent.rarityBoost[key] <= 0) {
                                throw new Error(`Invalid boost value for rarity '${key}'. Must be a positive number.`);
                            }
                        }
                    } catch (e) {
                        console.error("Invalid rarity_boost JSON:", e);
                        return interaction.editReply(`Error: Invalid JSON format for rarity_boost. Example: '{"rare": 2, "epic": 1.5}'. Details: ${e.message}`);
                    }
                }

                eventsData.activeEvents.push(newEvent);
                await saveEventsData(eventsData);
                await interaction.editReply(`✅ Event '${name}' (ID: ${id}) added successfully.`);
            } else if (subcommand === "remove") {
                const idToRemove = interaction.options.getString("id");
                const initialLength = eventsData.activeEvents.length;
                eventsData.activeEvents = eventsData.activeEvents.filter((event) => event.id !== idToRemove);

                if (eventsData.activeEvents.length === initialLength) {
                    await interaction.editReply(`Event with ID '${idToRemove}' not found.`);
                } else {
                    await saveEventsData(eventsData);
                    await interaction.editReply(`🗑️ Event with ID '${idToRemove}' removed successfully.`);
                }
            } else if (subcommand === "list") {
                if (!eventsData.activeEvents || eventsData.activeEvents.length === 0) {
                    return interaction.editReply("No scheduled events found.");
                }

                const now = new Date();
                const embed = new EmbedBuilder()
                    .setColor(0x0099FF)
                    .setTitle("📅 Scheduled Events")
                    .setTimestamp();

                // Sort events, e.g., by start time
                eventsData.activeEvents.sort((a, b) => new Date(a.startTime) - new Date(b.startTime));

                eventsData.activeEvents.forEach((event) => {
                    const startTime = new Date(event.startTime);
                    const endTime = new Date(event.endTime);
                    const isActive = now >= startTime && now <= endTime;
                    // eslint-disable-next-line max-len
                    let details = `**Type:** ${event.type}\n**Description:** ${event.description}\n**Time:** ${startTime.toLocaleString()} - ${endTime.toLocaleString()}`;
                    if (event.type === "xp_multiplier") details += `\n**Multiplier:** ${event.multiplier}x`;
                    if (event.type === "card_drop_boost") details += `\n**Boosts:** ${JSON.stringify(event.rarityBoost)}`;

                    embed.addFields({
                        name: `${isActive ? "🟢 Active" : "⚪️ Inactive"} | ${event.name} (ID: ${event.id})`,
                        value: details,
                    });
                });

                await interaction.editReply({ embeds: [embed] });
            }
        } catch (error) {
            console.error("Error executing /manage_event:", error);
            await interaction.editReply("An error occurred while managing events. Please check the logs.");
        }
    },
};
