const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const axios = require("axios");
const { getUser, updateUser, updateQuestProgress } = require("../../utils/userDataManager"); // Import updateQuestProgress

// دالة لجلب شخصية عشوائية مع صورة من Jikan API (مثال مبسط)
async function getRandomCharacter() {
    try {
        // الحصول على قائمة شخصيات مشهورة (يمكن تعديل المعايير)
        const topCharactersResponse = await axios.get("https://api.jikan.moe/v4/top/characters?limit=20");
        const characters = topCharactersResponse.data.data;
        if (!characters || characters.length === 0) {
            throw new Error("لم يتم العثور على شخصيات مشهورة.");
        }

        // اختيار شخصية عشوائية من القائمة
        const randomCharacterData = characters[Math.floor(Math.random() * characters.length)];

        // جلب تفاصيل الشخصية (للتأكد من وجود الصورة)
        const characterDetailsResponse = await axios.get(`https://api.jikan.moe/v4/characters/${randomCharacterData.mal_id}/full`);
        const character = characterDetailsResponse.data.data;

        if (!character || !character.images?.jpg?.image_url || !character.name) {
            // محاولة مرة أخرى إذا كانت البيانات غير مكتملة
            console.warn(`بيانات غير مكتملة للشخصية ${randomCharacterData.mal_id}, محاولة مرة أخرى...`);
            return getRandomCharacter(); // استدعاء العودية بحذر
        }

        return {
            name: character.name,
            imageUrl: character.images.jpg.image_url,
            mal_id: character.mal_id,
        };
    } catch (error) {
        console.error("خطأ في جلب شخصية عشوائية:", error.response?.data || error.message);
        // التعامل مع أخطاء حدود الاستخدام
        if (error.response?.status === 429) {
            throw new Error("تم الوصول إلى حد طلبات واجهة برمجة التطبيقات. يرجى المحاولة لاحقاً.");
        }
        throw new Error("حدث خطأ أثناء محاولة جلب شخصية للعبة.");
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guess")
        .setDescription("خمن اسم شخصية الأنمي من صورتها!"), // الشرح بالعربي
    async execute(interaction) {
        await interaction.deferReply();

        try {
            const character = await getRandomCharacter();

            const embed = new EmbedBuilder()
                .setColor(0xADD8E6) // Light Blue
                .setTitle("👤 من هي هذه الشخصية؟")
                .setDescription("لديك 60 ثانية لكتابة اسم الشخصية في الشات!")
                .setImage(character.imageUrl)
                .setFooter({ text: `ID: ${character.mal_id}` }); // يمكن إزالة الـ ID لاحقاً

            await interaction.editReply({ embeds: [embed] });

            // جمع الرسائل من المستخدم
            const filter = (m) => m.author.id === interaction.user.id;
            const collector = interaction.channel.createMessageCollector({ filter, time: 60000, max: 1 }); // 60 ثانية

            collector.on("collect", async (m) => {
                const guess = m.content.trim().toLowerCase();
                const correctName = character.name.toLowerCase();
                // مقارنة بسيطة (يمكن تحسينها لاحقاً للتعامل مع الأسماء المتعددة أو الألقاب)
                const isCorrect = guess === correctName || correctName.includes(guess) || guess.includes(correctName);

                const resultEmbed = EmbedBuilder.from(embed) // نسخ Embed الأصلي
                    .setDescription(null); // إزالة الوصف المؤقت

                let questCompletionMessage = "";

                if (isCorrect) {
                    resultEmbed.setColor(0x00FF00); // أخضر
                    resultEmbed.setTitle(`✅ صحيح! إنها ${character.name}`);
                    try {
                        // منح نقاط خبرة أساسية
                        const xpReward = 15; // نقاط ثابتة مبدئياً
                        await updateUser(interaction.user.id, { xp: (await getUser(interaction.user.id, interaction.user.username)).xp + xpReward });
                        resultEmbed.addFields({ name: "المكافأة الأساسية", value: `+${xpReward} نقطة خبرة! 🎉`, inline: false });

                        // تحديث تقدم المهمة اليومية
                        const questResult = await updateQuestProgress(interaction.user.id, "game_win", "guess");
                        if (questResult && questResult.completed.length > 0) {
                            questCompletionMessage = `\n🎉 **مهمة مكتملة:** ${questResult.completed[0].name} (+${questResult.xpReward} XP)!`;
                            if (questResult.awardedCard) {
                                questCompletionMessage += ` وحصلت على كرت: **${questResult.awardedCard.name}**!`;
                            }
                        }
                    } catch (err) {
                        console.error("خطأ في منح نقاط أو تحديث مهمة التخمين:", err);
                    }
                } else {
                    resultEmbed.setColor(0xFF0000); // أحمر
                    resultEmbed.setTitle(`❌ خطأ! الشخصية هي ${character.name}`);
                    resultEmbed.addFields({ name: "إجابتك", value: m.content, inline: false });
                }

                // إضافة رسالة إكمال المهمة إن وجدت
                if (questCompletionMessage) {
                    const currentDesc = resultEmbed.data.description || "";
                    resultEmbed.setDescription(currentDesc + questCompletionMessage);
                }

                await interaction.editReply({ embeds: [resultEmbed] });
                await m.delete().catch(console.error); // حذف رسالة الإجابة
            });

            collector.on("end", (collected) => {
                if (collected.size === 0) {
                    // إذا انتهى الوقت ولم يتم الإجابة
                    const timeoutEmbed = EmbedBuilder.from(embed)
                        .setColor(0xAAAAAA)
                        .setTitle(`⏳ انتهى الوقت! الشخصية كانت ${character.name}`)
                        .setDescription(null);
                    interaction.editReply({ embeds: [timeoutEmbed] }).catch(console.error);
                }
            });
        } catch (error) {
            console.error("خطأ في تنفيذ أمر التخمين:", error);
            await interaction.editReply({ content: `حدث خطأ: ${error.message}`, ephemeral: true });
        }
    },
};
