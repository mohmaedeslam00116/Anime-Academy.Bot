module.exports = {
    env: {
        commonjs: true,
        es2021: true,
        node: true,
    },
    extends: "airbnb-base",
    parserOptions: {
        ecmaVersion: 12,
    },
    rules: {
        indent: ["error", 4], // Use 4 spaces for indentation
        "linebreak-style": ["error", "unix"],
        quotes: ["error", "double"],
        semi: ["error", "always"],
        "no-console": "off", // Allow console.log for now
        "no-unused-vars": ["warn", { argsIgnorePattern: "^_" }], // Warn about unused vars
        "no-plusplus": "off", // Allow ++ operator
        "no-await-in-loop": "off", // Allow await in loops (sometimes necessary)
        "no-restricted-syntax": "off", // Allow for...of loops
        "no-shadow": "warn", // Warn about variable shadowing
        "no-param-reassign": "off", // Allow reassigning function parameters (e.g., in reducers or data manipulation)
        "consistent-return": "off", // Allow functions to sometimes return undefined implicitly
        "max-len": ["warn", { code: 150 }], // Warn if lines are too long
        "import/no-dynamic-require": "off", // Allow dynamic require
        "global-require": "off", // Allow require inside functions
        radix: ["error", "as-needed"], // Require radix parameter only when needed for parseInt
        "no-use-before-define": ["error", { functions: false, classes: true, variables: true }], // Allow function hoisting
        "no-underscore-dangle": "off", // Allow dangling underscores (e.g., for private methods convention)
        "no-continue": "off", // Allow continue statement in loops
        "object-curly-newline": "off", // Be flexible with object curly newline style
        "arrow-body-style": "off", // Be flexible with arrow function body style
        "prefer-destructuring": "off", // Don't force destructuring
        "no-promise-executor-return": "off", // Allow returning values from Promise executors
        "import/no-extraneous-dependencies": ["error", { devDependencies: true }], // Allow devDependencies import
    },
};
