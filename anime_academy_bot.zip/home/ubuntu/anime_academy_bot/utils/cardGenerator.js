const { createCanvas, loadImage, registerFont } = require("canvas");
const path = require("path");
const fs = require("fs-extra");

// --- Constants ---
const CARD_WIDTH = 350;
const CARD_HEIGHT = 500;
const PADDING = 20;
const IMAGE_HEIGHT_RATIO = 0.55;
const CORNER_RADIUS = 15;
const PLACEHOLDER_COLOR = "#E0E0E0";
const PLACEHOLDER_TEXT_COLOR = "#757575";
const DEFAULT_RARITY_COLOR = "#A9A9A9";
const CARD_BG_COLOR = "#FFFFFF";
const CARD_NAME_COLOR = "#000000";
const CARD_SERIES_COLOR = "#555555";
const CARD_ID_COLOR = "#AAAAAA";

// --- Font Registration (Consistent with profileCardGenerator) ---
const FONT_REGULAR_PATH = path.join(__dirname, "../assets/fonts/Poppins-Regular.ttf");
const FONT_BOLD_PATH = path.join(__dirname, "../assets/fonts/Poppins-Bold.ttf");
let cardFontsRegistered = false;

function registerCardFonts() {
    if (cardFontsRegistered) return;
    try {
        if (fs.existsSync(FONT_REGULAR_PATH)) {
            registerFont(FONT_REGULAR_PATH, { family: "Poppins" });
        } else {
            console.warn(`[CardGenerator] Regular font not found: ${FONT_REGULAR_PATH}`);
        }
        if (fs.existsSync(FONT_BOLD_PATH)) {
            registerFont(FONT_BOLD_PATH, { family: "Poppins", weight: "bold" });
        } else {
            console.warn(`[CardGenerator] Bold font not found: ${FONT_BOLD_PATH}`);
        }
        cardFontsRegistered = true;
        console.log("[CardGenerator] Poppins fonts registered.");
    } catch (error) {
        console.error("[CardGenerator] Error registering fonts:", error);
    }
}

// --- Drawing Utilities ---

/**
 * Draws a rounded rectangle path.
 * @param {CanvasRenderingContext2D} ctx - The canvas rendering context.
 * @param {number} x - The x-coordinate.
 * @param {number} y - The y-coordinate.
 * @param {number} width - The width.
 * @param {number} height - The height.
 * @param {number} radius - The corner radius.
 */
function roundRectPath(ctx, x, y, width, height, radius) {
    if (width < 2 * radius) radius = width / 2;
    if (height < 2 * radius) radius = height / 2;
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + width, y, x + width, y + height, radius);
    ctx.arcTo(x + width, y + height, x, y + height, radius);
    ctx.arcTo(x, y + height, x, y, radius);
    ctx.arcTo(x, y, x + width, y, radius);
    ctx.closePath();
}

/**
 * Wraps text to fit within a maximum width.
 * @param {CanvasRenderingContext2D} context - The canvas rendering context.
 * @param {string} text - The text to wrap.
 * @param {number} x - The starting x-coordinate.
 * @param {number} y - The starting y-coordinate.
 * @param {number} maxWidth - The maximum width for the text.
 * @param {number} lineHeight - The height of each line.
 * @returns {number} The total height used by the wrapped text.
 */
function wrapText(context, text, x, y, maxWidth, lineHeight) {
    const words = text.split(" ");
    let line = "";
    let currentY = y;

    for (let n = 0; n < words.length; n++) {
        const testLine = `${line + words[n]} `;
        const metrics = context.measureText(testLine);
        const testWidth = metrics.width;
        if (testWidth > maxWidth && n > 0) {
            context.fillText(line.trim(), x, currentY);
            line = `${words[n]} `;
            currentY += lineHeight;
        } else {
            line = testLine;
        }
    }
    context.fillText(line.trim(), x, currentY);
    return currentY - y + lineHeight; // Return total height
}

// --- Main Card Generation Function ---

/**
 * Generates a card image buffer based on card data and rarity info.
 * @param {object} cardData - The card data (id, name, imageUrl, series, rarity).
 * @param {object} rarityInfo - The rarity details (name, color).
 * @returns {Promise<Buffer|null>} The image buffer (PNG) or null on error.
 */
async function generateCardImage(cardData, rarityInfo) {
    registerCardFonts(); // Ensure fonts are registered
    const canvas = createCanvas(CARD_WIDTH, CARD_HEIGHT);
    const ctx = canvas.getContext("2d");

    // --- Background and Border ---
    ctx.fillStyle = rarityInfo?.color || DEFAULT_RARITY_COLOR;
    roundRectPath(ctx, 0, 0, CARD_WIDTH, CARD_HEIGHT, CORNER_RADIUS);
    ctx.fill();
    // Inner background
    ctx.fillStyle = CARD_BG_COLOR;
    const innerPadding = PADDING / 2;
    roundRectPath(ctx, innerPadding, innerPadding, CARD_WIDTH - PADDING, CARD_HEIGHT - PADDING, CORNER_RADIUS - (innerPadding / 2));
    ctx.fill();

    // --- Card Image ---
    const imageY = PADDING;
    const imageMaxHeight = CARD_HEIGHT * IMAGE_HEIGHT_RATIO;
    const imageAvailableWidth = CARD_WIDTH - PADDING * 2;
    const drawPlaceholder = (text) => {
        ctx.fillStyle = PLACEHOLDER_COLOR;
        ctx.fillRect(PADDING, imageY, imageAvailableWidth, imageMaxHeight);
        ctx.fillStyle = PLACEHOLDER_TEXT_COLOR;
        ctx.font = "bold 20px Poppins";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(text, CARD_WIDTH / 2, imageY + imageMaxHeight / 2);
        ctx.textBaseline = "alphabetic"; // Reset baseline
    };

    try {
        if (cardData?.imageUrl && cardData.imageUrl !== "(سيتم إضافة رابط صورة لاحقاً)") {
            const image = await loadImage(cardData.imageUrl);
            // Calculate dimensions to fit and maintain aspect ratio
            let drawWidth = imageAvailableWidth;
            let drawHeight = (image.height / image.width) * drawWidth;
            if (drawHeight > imageMaxHeight) {
                drawHeight = imageMaxHeight;
                drawWidth = (image.width / image.height) * drawHeight;
            }
            const drawX = PADDING + (imageAvailableWidth - drawWidth) / 2;
            ctx.drawImage(image, drawX, imageY, drawWidth, drawHeight);
        } else {
            drawPlaceholder("لا توجد صورة");
        }
    } catch (error) {
        console.error(`[CardGenerator] Error loading image for card ${cardData?.id}:`, error);
        drawPlaceholder("خطأ بالصورة");
    }

    // --- Card Name ---
    const nameY = imageY + imageMaxHeight + PADDING * 1.5;
    ctx.fillStyle = CARD_NAME_COLOR;
    ctx.font = "bold 24px Poppins";
    ctx.textAlign = "center";
    wrapText(ctx, cardData?.name || "اسم غير معروف", CARD_WIDTH / 2, nameY, CARD_WIDTH - PADDING * 2, 30);

    // --- Rarity and Series ---
    const detailsY = CARD_HEIGHT - PADDING * 2.5; // Position from bottom
    ctx.font = "18px Poppins";
    ctx.textAlign = "left";
    ctx.fillStyle = rarityInfo?.color || CARD_NAME_COLOR; // Use rarity color for rarity text
    ctx.fillText(`الندرة: ${rarityInfo?.name || cardData?.rarity || "غير معروف"}`, PADDING, detailsY);

    ctx.fillStyle = CARD_SERIES_COLOR;
    ctx.textAlign = "right";
    ctx.fillText(cardData?.series || "", CARD_WIDTH - PADDING, detailsY);

    // --- Card ID (Optional) ---
    ctx.fillStyle = CARD_ID_COLOR;
    ctx.font = "12px Poppins";
    ctx.textAlign = "center";
    ctx.fillText(`ID: ${cardData?.id || "N/A"}`, CARD_WIDTH / 2, CARD_HEIGHT - PADDING / 2);

    // --- Return Buffer ---
    try {
        return canvas.toBuffer("image/png");
    } catch (bufferError) {
        console.error("[CardGenerator] Error converting canvas to buffer:", bufferError);
        return null;
    }
}

module.exports = { generateCardImage };
