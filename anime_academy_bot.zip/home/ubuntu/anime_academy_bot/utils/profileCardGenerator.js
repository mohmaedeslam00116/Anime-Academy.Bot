const { createCanvas, loadImage, registerFont } = require("canvas");
const path = require("path");
const fs = require("fs-extra");

// --- Constants ---
const CARD_WIDTH = 800;
const CARD_HEIGHT = 250;
const AVATAR_SIZE = 180;
const PADDING = 30;
const BORDER_RADIUS = 20;
const AVATAR_BORDER_WIDTH = 6;
const DEFAULT_LEVEL = 1; // Define default level

// --- House Colors (Centralized for consistency) ---
// Consider moving this to a shared config/constants file if used elsewhere
const HOUSE_COLORS = {
    fire_red: { name: "النار الأحمر", primary: "#E74C3C", secondary: "#C0392B" },
    water_blue: { name: "الماء الأزرق", primary: "#3498DB", secondary: "#2980B9" },
    earth_green: { name: "الأرض الأخضر", primary: "#2ECC71", secondary: "#27AE60" },
    air_gold: { name: "الهواء الذهبي", primary: "#F1C40F", secondary: "#F39C12" },
    default: { name: "غير محدد", primary: "#95A5A6", secondary: "#7F8C8D" }, // Default color for unassigned house
};

// --- Font Registration ---
const FONT_REGULAR_PATH = path.join(__dirname, "../assets/fonts/Poppins-Regular.ttf");
const FONT_BOLD_PATH = path.join(__dirname, "../assets/fonts/Poppins-Bold.ttf");
let fontsRegistered = false;

function registerProfileFonts() {
    if (fontsRegistered) return;
    try {
        if (fs.existsSync(FONT_REGULAR_PATH)) {
            registerFont(FONT_REGULAR_PATH, { family: "Poppins" });
        } else {
            console.warn(`[ProfileCard] Regular font not found: ${FONT_REGULAR_PATH}`);
        }
        if (fs.existsSync(FONT_BOLD_PATH)) {
            registerFont(FONT_BOLD_PATH, { family: "Poppins", weight: "bold" });
        } else {
            console.warn(`[ProfileCard] Bold font not found: ${FONT_BOLD_PATH}`);
        }
        fontsRegistered = true;
        console.log("[ProfileCard] Poppins fonts registered.");
    } catch (error) {
        console.error("[ProfileCard] Error registering fonts:", error);
        // Proceed without custom fonts if registration fails
    }
}

// --- Drawing Utilities ---

/**
 * Draws a rounded rectangle path.
 * @param {CanvasRenderingContext2D} ctx - The canvas rendering context.
 * @param {number} x - The x-coordinate of the top-left corner.
 * @param {number} y - The y-coordinate of the top-left corner.
 * @param {number} width - The width of the rectangle.
 * @param {number} height - The height of the rectangle.
 * @param {number} radius - The corner radius.
 */
function roundRectPath(ctx, x, y, width, height, radius) {
    let effectiveRadius = radius;
    if (width < 2 * effectiveRadius) effectiveRadius = width / 2;
    if (height < 2 * effectiveRadius) effectiveRadius = height / 2;
    ctx.beginPath();
    ctx.moveTo(x + effectiveRadius, y);
    ctx.arcTo(x + width, y, x + width, y + height, effectiveRadius);
    ctx.arcTo(x + width, y + height, x, y + height, effectiveRadius);
    ctx.arcTo(x, y + height, x, y, effectiveRadius);
    ctx.arcTo(x, y, x + width, y, effectiveRadius);
    ctx.closePath();
}

/**
 * Draws a progress bar.
 * @param {CanvasRenderingContext2D} ctx - The canvas rendering context.
 * @param {number} x - The x-coordinate.
 * @param {number} y - The y-coordinate.
 * @param {number} width - The width of the bar.
 * @param {number} height - The height of the bar.
 * @param {number} progress - The progress value (0 to 1).
 * @param {string} color - The fill color for the progress.
 * @param {string} backgroundColor - The background color of the bar.
 */
function drawProgressBar(ctx, x, y, width, height, progress, color, backgroundColor = "#444") {
    const radius = height / 2;
    // Background
    ctx.fillStyle = backgroundColor;
    roundRectPath(ctx, x, y, width, height, radius);
    ctx.fill();

    // Progress Fill
    if (progress > 0) {
        // Ensure progress width is at least the height (for rounded ends) and capped at total width
        const progressWidth = Math.max(height, width * Math.min(progress, 1));
        ctx.fillStyle = color;
        roundRectPath(ctx, x, y, progressWidth, height, radius);
        ctx.fill();
    }
}

// --- Main Card Generation Function ---

/**
 * Creates a profile card image buffer.
 * @param {User} user - The Discord user object.
 * @param {object} userData - The user data object from userDataManager.
 * @returns {Promise<Buffer|null>} The image buffer (PNG) or null on error.
 */
async function createProfileCard(user, userData) {
    registerProfileFonts(); // Ensure fonts are registered
    const canvas = createCanvas(CARD_WIDTH, CARD_HEIGHT);
    const ctx = canvas.getContext("2d");

    // --- Background ---
    const houseInfo = HOUSE_COLORS[userData?.house] || HOUSE_COLORS.default;
    ctx.fillStyle = houseInfo.primary;
    roundRectPath(ctx, 0, 0, CARD_WIDTH, CARD_HEIGHT, BORDER_RADIUS);
    ctx.fill();

    // --- Avatar ---
    const avatarX = PADDING;
    const avatarY = PADDING;
    try {
        const avatarUrl = user.displayAvatarURL({ extension: "png", size: 256 });
        const avatar = await loadImage(avatarUrl);
        ctx.save();
        ctx.beginPath();
        ctx.arc(avatarX + AVATAR_SIZE / 2, avatarY + AVATAR_SIZE / 2, AVATAR_SIZE / 2, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);
        ctx.restore();

        // Avatar Border
        ctx.strokeStyle = houseInfo.secondary;
        ctx.lineWidth = AVATAR_BORDER_WIDTH;
        ctx.beginPath();
        ctx.arc(avatarX + AVATAR_SIZE / 2, avatarY + AVATAR_SIZE / 2, AVATAR_SIZE / 2, 0, Math.PI * 2, true);
        ctx.stroke();
    } catch (error) {
        console.error(`[ProfileCard] Error loading/drawing avatar for ${user.id}:`, error);
        // Draw placeholder circle on error
        ctx.fillStyle = "#FFF";
        ctx.beginPath();
        ctx.arc(avatarX + AVATAR_SIZE / 2, avatarY + AVATAR_SIZE / 2, AVATAR_SIZE / 2, 0, Math.PI * 2, true);
        ctx.fill();
    }

    // --- Text Information ---
    const textX = AVATAR_SIZE + PADDING * 2;
    const textBlockWidth = CARD_WIDTH - textX - PADDING;

    // Username
    const nameY = PADDING + 45;
    ctx.fillStyle = "#FFFFFF";
    ctx.font = "bold 38px Poppins";
    ctx.fillText(user.username, textX, nameY, textBlockWidth); // Add maxWidth

    // Level and House
    const levelY = nameY + 45;
    ctx.font = "28px Poppins";
    ctx.fillStyle = "#DDDDDD";
    const levelText = `Level: ${userData?.level || DEFAULT_LEVEL}`;
    const houseText = `البيت: ${houseInfo.name}`; // Keep house name Arabic as requested
    ctx.fillText(`${levelText} | ${houseText}`, textX, levelY, textBlockWidth); // Add maxWidth

    // --- XP Bar ---
    const barHeight = 25;
    const barX = textX;
    const barY = CARD_HEIGHT - PADDING - barHeight - 15;
    const requiredXP = 1000; // TODO: Make this dynamic based on level (e.g., use a formula)
    const currentXP = userData?.xp || 0;
    const progress = requiredXP > 0 ? (currentXP / requiredXP) : 0; // Avoid division by zero

    drawProgressBar(ctx, barX, barY, textBlockWidth, barHeight, progress, houseInfo.secondary);

    // XP Text
    ctx.font = "bold 18px Poppins";
    ctx.fillStyle = "#FFFFFF";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(`${currentXP} / ${requiredXP} XP`, barX + textBlockWidth / 2, barY + barHeight / 2);
    ctx.textAlign = "start"; // Reset alignment
    ctx.textBaseline = "alphabetic"; // Reset baseline

    // --- Return Buffer ---
    try {
        return canvas.toBuffer("image/png");
    } catch (bufferError) {
        console.error("[ProfileCard] Error converting canvas to buffer:", bufferError);
        return null;
    }
}

module.exports = { createProfileCard };
