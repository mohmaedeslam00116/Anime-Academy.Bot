const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { getUser, updateUser, getActiveEvents, getRandomCardInternal } = require("../../utils/userDataManager");
const { generateCardImage } = require("../../utils/cardGenerator");

const shopFilePath = path.join(__dirname, "../../data/shop.json");
const cardsFilePath = path.join(__dirname, "../../data/cards.json");

// دالة لتحميل بيانات المتجر
async function loadShopData() {
    try {
        const data = await fs.readJson(shopFilePath);
        return data.items || [];
    } catch (error) {
        console.error("خطأ في تحميل بيانات المتجر:", error);
        return [];
    }
}

// دالة لاختيار كرت عشوائي بناءً على احتمالات الحزمة
async function getRandomCardFromPack(packDetails) {
    try {
        const cardsData = await fs.readJson(cardsFilePath);
        if (!cardsData || !cardsData.cards || !cardsData.rarities) {
            throw new Error("ملف بيانات الكروت غير صالح.");
        }

        const rarities = cardsData.rarities;
        const cards = cardsData.cards;
        const packRarityChances = packDetails.rarityChances || {};
        const totalPackDropRate = Object.values(packRarityChances).reduce((sum, chance) => sum + chance, 0);

        if (totalPackDropRate <= 0) {
            console.warn("احتمالات الندرة في الحزمة غير صالحة أو مجموعها صفر.");
            return await getRandomCardInternal(); // استخدام الاختيار العشوائي العام كاحتياطي
        }

        let random = Math.random() * totalPackDropRate;
        let selectedRarityKey = null;

        // ترتيب الندرات حسب الاحتمال في الحزمة (أو ترتيب عام إذا لم يكن هناك ترتيب محدد)
        const sortedRarityKeys = Object.keys(packRarityChances).sort((a, b) => (rarities[b]?.order || 0) - (rarities[a]?.order || 0));

        for (const rarityKey of sortedRarityKeys) {
            if (packRarityChances[rarityKey] && random < packRarityChances[rarityKey]) {
                selectedRarityKey = rarityKey;
                break;
            }
            if (packRarityChances[rarityKey]) {
                random -= packRarityChances[rarityKey];
            }
        }

        if (!selectedRarityKey) {
            // إذا لم يتم اختيار ندرة من الحزمة (قد يحدث بسبب أخطاء التقريب)، اختر ندرة عشوائية من المتوفرة في الحزمة
            const availableRarities = Object.keys(packRarityChances).filter((r) => packRarityChances[r] > 0);
            if (availableRarities.length > 0) {
                selectedRarityKey = availableRarities[Math.floor(Math.random() * availableRarities.length)];
            } else {
                selectedRarityKey = "common"; // افتراضي نهائي
            }
        }

        const cardsOfSelectedRarity = cards.filter((card) => card.rarity === selectedRarityKey);
        if (cardsOfSelectedRarity.length === 0) {
            console.warn(`لا توجد كروت بالندرة المختارة (${selectedRarityKey}) من الحزمة. محاولة إعطاء كرت عادي.`);
            const commonCards = cards.filter((card) => card.rarity === "common");
            if (commonCards.length === 0) return null;
            const chosenCard = commonCards[Math.floor(Math.random() * commonCards.length)];
            return { ...chosenCard, rarityData: rarities.common };
        }

        const chosenCard = cardsOfSelectedRarity[Math.floor(Math.random() * cardsOfSelectedRarity.length)];
        return { ...chosenCard, rarityData: rarities[selectedRarityKey] };
    } catch (error) {
        console.error("خطأ في اختيار كرت عشوائي من الحزمة:", error);
        return null;
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("buy")
        .setDescription("شراء عنصر من المتجر باستخدام نقاط الخبرة.")
        .addStringOption((option) => option.setName("item_id")
            .setDescription("معرف العنصر الذي تريد شراءه (من أمر /shop)")
            .setRequired(true)),
    async execute(interaction) {
        const userId = interaction.user.id;
        const username = interaction.user.username;
        const itemIdToBuy = interaction.options.getString("item_id");
        await interaction.deferReply({ ephemeral: true });

        try {
            const userData = await getUser(userId, username);
            const shopItems = await loadShopData();
            const activeEvents = await getActiveEvents(); // قد تؤثر الأحداث على الأسعار مستقبلاً؟

            const item = shopItems.find((i) => i.id === itemIdToBuy);

            if (!item) {
                return interaction.editReply({ content: `❌ لم يتم العثور على عنصر بالمعرف ".${itemIdToBuy}". استخدم "./shop" لرؤية العناصر المتاحة.` });
            }

            const userXP = userData.xp || 0;
            const itemCost = item.cost || 0;

            if (userXP < itemCost) {
                return interaction.editReply({ content: `😔 ليس لديك نقاط خبرة كافية لشراء "${item.name}". تحتاج إلى ${itemCost} ولديك ${userXP} نقطة.` });
            }

            // خصم النقاط
            const newXP = userXP - itemCost;
            const updatePayload = { xp: newXP };
            let replyMessage = `✅ تم شراء "${item.name}" بنجاح مقابل ${itemCost} نقطة خبرة! رصيدك الحالي هو ${newXP} نقطة.`;
            let cardAttachment = null;
            let cardEmbed = null;

            // تطبيق تأثير العنصر
            if (item.type === "card_pack") {
                const awardedCard = await getRandomCardFromPack(item.packDetails);
                if (awardedCard) {
                    const updatedCollection = userData.collection || [];
                    const cardExists = updatedCollection.find((c) => c.id === awardedCard.id);
                    if (cardExists) {
                        cardExists.count = (cardExists.count || 1) + 1;
                    } else {
                        updatedCollection.push({ id: awardedCard.id, count: 1 });
                    }
                    updatePayload.collection = updatedCollection;
                    replyMessage += `\n🎁 لقد حصلت على كرت: **${awardedCard.name}** [${awardedCard.rarityData?.name || awardedCard.rarity}]!`;

                    // توليد صورة الكرت
                    try {
                        const cardImageBuffer = await generateCardImage(awardedCard, awardedCard.rarityData);
                        cardAttachment = new AttachmentBuilder(cardImageBuffer, { name: `buy-card-${awardedCard.id}.png` });
                        cardEmbed = new EmbedBuilder()
                            .setColor(awardedCard.rarityData?.color || 0xAAAAAA)
                            .setTitle("🎁 كرت من الحزمة! 🎁")
                            .setDescription(`لقد حصلت على كرت **${awardedCard.name}** من حزمة ${item.name}!`)
                            .setImage(`attachment://buy-card-${awardedCard.id}.png`);
                    } catch (imgError) {
                        console.error(`خطأ في توليد صورة الكرت من الشراء ${awardedCard.id}:`, imgError);
                        replyMessage += " (لم نتمكن من عرض صورة الكرت حالياً)";
                    }
                } else {
                    replyMessage += "\n😕 لم يحالفك الحظ في الحصول على كرت من هذه الحزمة هذه المرة.";
                }
            } else if (item.type === "boost") {
                // --- منطق تطبيق التعزيزات (يتطلب تعديل userDataManager لتخزين وإدارة التعزيزات النشطة) ---
                // مثال مبسط: إضافة خاصية للتعزيز النشط
                const boostEndTime = new Date(Date.now() + (item.boostDetails.durationMinutes || 0) * 60 * 1000);
                const activeBoosts = userData.activeBoosts || [];
                activeBoosts.push({
                    id: item.id,
                    type: item.boostDetails.stat,
                    multiplier: item.boostDetails.multiplier,
                    endTime: boostEndTime.toISOString(),
                });
                updatePayload.activeBoosts = activeBoosts;
                replyMessage += `\n🚀 تم تفعيل تعزيز ${item.name} لمدة ${item.boostDetails.durationMinutes} دقيقة!`;
                // ملاحظة: يجب تعديل الأماكن التي تمنح الخبرة (مثل daily, quests) للتحقق من التعزيزات النشطة
            }
            // ... يمكن إضافة أنواع عناصر أخرى هنا

            // تحديث بيانات المستخدم
            const updateResult = await updateUser(userId, updatePayload, activeEvents);

            if (updateResult) {
                const finalPayload = {
                    content: replyMessage,
                    embeds: cardEmbed ? [cardEmbed] : [],
                    files: cardAttachment ? [cardAttachment] : [],
                    ephemeral: true,
                };
                await interaction.editReply(finalPayload);
            } else {
                // يجب إعادة النقاط نظرياً إذا فشل التحديث، لكن هذا يعقد الأمور
                await interaction.editReply({ content: "حدث خطأ أثناء تحديث بياناتك بعد الشراء. يرجى التواصل مع المشرفين.", ephemeral: true });
            }
        } catch (error) {
            console.error("خطأ في أمر /buy:", error);
            await interaction.editReply({ content: "حدث خطأ أثناء محاولة الشراء.", ephemeral: true });
        }
    },
};
