const { SlashCommandBuilder, EmbedBuilder, StringSelectMenuBuilder, ActionRowBuilder, ComponentType } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");

const guideFilePath = path.join(__dirname, "../../data/guide_npc.json");

// دالة لتحميل بيانات الدليل
async function loadGuideData() {
    try {
        const data = await fs.readJson(guideFilePath);
        return data || { guideName: "مرشد الأكاديمية", topics: [] };
    } catch (error) {
        console.error("خطأ في تحميل بيانات الدليل:", error);
        return { guideName: "مرشد الأكاديمية", topics: [] };
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("guide")
        .setDescription("احصل على مساعدة وإرشادات حول ميزات الأكاديمية من المرشد."),
    // .addStringOption(option =>
    //     option.setName("topic")
    //         .setDescription("الموضوع الذي تريد السؤال عنه (اتركه فارغاً لعرض كل المواضيع)")
    //         .setRequired(false)), // سنجعلها قائمة منسدلة بدلاً من خيار نصي
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        try {
            const guideData = await loadGuideData();
            const npcName = guideData.guideName || "مرشد الأكاديمية";

            if (guideData.topics.length === 0) {
                return interaction.editReply({ content: "عذراً، لا توجد مواضيع مساعدة متاحة حالياً." });
            }

            // إنشاء قائمة منسدلة بالمواضيع
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId("guide_topic_select")
                .setPlaceholder("اختر موضوعاً للحصول على المساعدة...")
                .addOptions(
                    guideData.topics.map((topic) => ({
                        label: topic.label || topic.id, // استخدام الاسم المعرفي إن وجد
                        description: topic.response.substring(0, 100) + (topic.response.length > 100 ? "..." : ""), // وصف مختصر
                        value: topic.id,
                    })),
                );

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const initialEmbed = new EmbedBuilder()
                .setColor(0x9B59B6) // لون بنفسجي للمرشد
                .setTitle(`🎙️ ${npcName} في الخدمة!`)
                .setDescription("أهلاً بك! أنا هنا لمساعدتك في استكشاف أكاديمية عالم الأنمي. اختر أحد المواضيع أدناه لمعرفة المزيد:")
                .setFooter({ text: "سيختفي هذا التفاعل بعد دقيقتين." });

            const reply = await interaction.editReply({
                embeds: [initialEmbed],
                components: [row],
                ephemeral: true,
            });

            // مجمع للاستجابة لاختيار القائمة
            const collector = reply.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
                time: 120000, // دقيقتان
            });

            collector.on("collect", async (i) => {
                if (i.user.id !== interaction.user.id) {
                    await i.reply({ content: "لا يمكنك استخدام هذه القائمة.", ephemeral: true });
                    return;
                }

                const selectedTopicId = i.values[0];
                const selectedTopic = guideData.topics.find((topic) => topic.id === selectedTopicId);

                if (selectedTopic) {
                    const topicEmbed = new EmbedBuilder()
                        .setColor(0x9B59B6)
                        .setTitle(`🎙️ ${npcName} يشرح: ${selectedTopic.label || selectedTopic.id}`)
                        .setDescription(selectedTopic.response)
                        .setTimestamp();

                    // تحديث الرد لعرض الشرح وإزالة القائمة (أو إبقائها مع تحديث الحالة؟)
                    // سنقوم بتحديث الرد الأصلي ليكون الشرح فقط
                    await i.update({ embeds: [topicEmbed], components: [] });
                } else {
                    await i.update({ content: "عذراً، لم أتمكن من العثور على معلومات حول هذا الموضوع.", embeds: [], components: [] });
                }
                collector.stop(); // إيقاف المجمع بعد الاختيار
            });

            collector.on("end", async (collected, reason) => {
                if (reason === "time") {
                    // إزالة المكونات إذا انتهى الوقت ولم يتم الاختيار
                    const timeoutEmbed = new EmbedBuilder()
                        .setColor(0xAAAAAA)
                        .setTitle(`🎙️ ${npcName}`)
                        .setDescription("انتهى وقت التفاعل. يمكنك استخدام الأمر `/guide` مرة أخرى إذا احتجت للمساعدة.");
                    await interaction.editReply({ embeds: [timeoutEmbed], components: [] }).catch(console.error);
                }
                // إذا تم الاختيار، فقد تم التعامل معه في 'collect'
            });
        } catch (error) {
            console.error("خطأ في أمر /guide:", error);
            await interaction.editReply({ content: "حدث خطأ أثناء محاولة عرض دليل المساعدة.", embeds: [], components: [] });
        }
    },
};
