const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const axios = require("axios");
const { getUser, loadHousesData } = require("../../utils/userDataManager");

// رابط Jikan API
const JIKAN_API_BASE = "https://api.jikan.moe/v4";

// ربط البيوت بالأنواع المقترحة (يمكن توسيعها)
const houseGenreMap = {
    fire_red: [1, 2], // Action, Adventure
    water_blue: [7, 40], // Mystery, Psychological
    earth_green: [4, 36], // Comedy, Slice of Life
    air_golden: [10, 24], // Fantasy, Sci-Fi
};

// دالة لجلب أفضل الأنميات حسب النوع من Jikan
async function getTopAnimeByGenre(genreIds, limit = 5) {
    try {
        const genreQuery = genreIds.join(",");
        const response = await axios.get(`${JIKAN_API_BASE}/top/anime`, {
            params: {
                filter: "bypopularity",
                genres: genreQuery,
                limit: limit * 2, // جلب المزيد لتصفية النتائج لاحقاً إذا لزم الأمر
            },
        });
        return response.data.data || [];
    } catch (error) {
        console.error("خطأ في جلب الأنمي حسب النوع من Jikan:", error.response?.data || error.message);
        return [];
    }
}

// دالة لجلب أفضل الأنميات بشكل عام
async function getTopAnimeOverall(limit = 5) {
    try {
        const response = await axios.get(`${JIKAN_API_BASE}/top/anime`, {
            params: {
                filter: "bypopularity",
                limit,
            },
        });
        return response.data.data || [];
    } catch (error) {
        console.error("خطأ في جلب أفضل الأنميات من Jikan:", error.response?.data || error.message);
        return [];
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("recommend")
        .setDescription("احصل على توصيات أنمي بناءً على بيتك أو الشعبية العامة!"),
    async execute(interaction) {
        await interaction.deferReply();
        const userId = interaction.user.id;
        const username = interaction.user.username;

        try {
            const userData = await getUser(userId, username);
            let recommendations = [];
            let recommendationSource = "الشعبية العامة"; // المصدر الافتراضي

            // 1. محاولة التوصية بناءً على البيت
            if (userData.house && houseGenreMap[userData.house]) {
                const houseGenres = houseGenreMap[userData.house];
                recommendations = await getTopAnimeByGenre(houseGenres, 5);
                if (recommendations.length > 0) {
                    const housesData = await loadHousesData();
                    recommendationSource = `بيت ${housesData[userData.house]?.name || userData.house}`;
                }
            }

            // 2. إذا لم تنجح توصية البيت، استخدم الشعبية العامة
            if (recommendations.length === 0) {
                recommendations = await getTopAnimeOverall(5);
                recommendationSource = "الشعبية العامة";
            }

            if (recommendations.length === 0) {
                await interaction.editReply("عذراً، لم نتمكن من العثور على توصيات لك في الوقت الحالي.");
                return;
            }

            // 3. إنشاء Embed لعرض التوصيات
            const embed = new EmbedBuilder()
                .setColor(0xFFAC33) // لون برتقالي مميز
                .setTitle("🌟 توصيات الأنمي لك 🌟")
                .setDescription(`بناءً على **${recommendationSource}**، قد تستمتع بهذه الأعمال:`)
                .setTimestamp();

            recommendations.slice(0, 5).forEach((anime, index) => {
                embed.addFields({
                    name: `${index + 1}. ${anime.title_english || anime.title}`,
                    value: `⭐ ${anime.score || "N/A"} | ${anime.type || "N/A"} | ${anime.episodes ? `${anime.episodes} حلقة` : "غير معروف"}\n[صفحة الأنمي](<${anime.url}>)`,
                    inline: false,
                });
            });

            // إضافة صورة مصغرة لأول توصية
            if (recommendations[0]?.images?.jpg?.image_url) {
                embed.setThumbnail(recommendations[0].images.jpg.image_url);
            }

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error("خطأ في أمر /recommend:", error);
            await interaction.editReply("حدث خطأ أثناء محاولة جلب التوصيات.");
        }
    },
};
