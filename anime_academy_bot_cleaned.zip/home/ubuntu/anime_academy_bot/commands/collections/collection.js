const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, AttachmentBuilder } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { getUser } = require("../../utils/userDataManager");
const { generateCardImage } = require("../../utils/cardGenerator"); // استيراد مولد صور الكروت

const cardsFilePath = path.join(__dirname, "../../data/cards.json");
const ITEMS_PER_PAGE = 5; // تقليل عدد الكروت لعرض الصور بشكل أفضل؟ أو عرض صورة واحدة فقط

// دالة لتحميل بيانات الكروت الكاملة
async function loadCardsData() {
    try {
        const data = await fs.readJson(cardsFilePath);
        return data || { cards: [], rarities: {} };
    } catch (error) {
        console.error("خطأ في تحميل بيانات الكروت:", error);
        return { cards: [], rarities: {} };
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("collection")
        .setDescription("عرض مجموعة الكروت التي جمعتها مع الصور!")
        .addUserOption((option) => option.setName("user")
            .setDescription("المستخدم الذي تريد عرض مجموعته (اختياري)")
            .setRequired(false)),
    async execute(interaction) {
        await interaction.deferReply();

        const targetUser = interaction.options.getUser("user") || interaction.user;
        const userId = targetUser.id;
        const username = targetUser.username;

        try {
            const userData = await getUser(userId, username);
            const cardsData = await loadCardsData();

            if (!userData || !userData.collection || userData.collection.length === 0) {
                const embed = new EmbedBuilder()
                    .setColor(0xAAAAAA)
                    .setTitle(`مجموعة ${username}`)
                    .setDescription("لم تجمع أي كروت بعد. استخدم `/daily` للحصول على فرصتك اليومية!");
                await interaction.editReply({ embeds: [embed] });
                return;
            }

            // ربط بيانات الكروت مع مجموعة المستخدم
            const userCards = userData.collection.map((userCard) => {
                const cardInfo = cardsData.cards.find((c) => c.id === userCard.id);
                if (!cardInfo) return null; // تجاهل الكروت غير الموجودة
                const rarityInfo = cardsData.rarities[cardInfo.rarity] || { name: cardInfo.rarity || "غير معروف", color: "#A9A9A9" };
                return {
                    ...cardInfo,
                    count: userCard.count,
                    rarityName: rarityInfo.name,
                    rarityColor: rarityInfo.color,
                    rarityData: rarityInfo, // نحتاج لمعلومات الندرة كاملة للصورة
                };
            }).filter((card) => card !== null); // تصفية الكروت غير الموجودة

            // فرز الكروت (مثلاً حسب الندرة ثم الاسم)
            userCards.sort((a, b) => {
                const rarityOrder = { legendary: 4, epic: 3, rare: 2, common: 1 };
                const rarityA = rarityOrder[a.rarity] || 0;
                const rarityB = rarityOrder[b.rarity] || 0;
                if (rarityB !== rarityA) return rarityB - rarityA;
                return a.name.localeCompare(b.name);
            });

            const totalPages = Math.ceil(userCards.length / ITEMS_PER_PAGE);
            let currentPage = 0;

            // دالة لإنشاء Embed وملف الصورة للصفحة الحالية
            const generatePageContent = async (page) => {
                const start = page * ITEMS_PER_PAGE;
                const end = start + ITEMS_PER_PAGE;
                const currentCards = userCards.slice(start, end);

                let attachment = null;
                const embed = new EmbedBuilder()
                    .setColor(0x3498DB) // Blue
                    .setTitle(`مجموعة ${username} (صفحة ${page + 1}/${totalPages})`)
                    .setFooter({ text: `إجمالي الكروت: ${userCards.length}` });

                if (currentCards.length > 0) {
                    // إنشاء وصف نصي للكروت في الصفحة
                    embed.setDescription(currentCards.map((card) => `**${card.name}** [${card.rarityName}] (x${card.count})`).join("\n"));

                    // توليد صورة لأول كرت في الصفحة
                    try {
                        const firstCard = currentCards[0];
                        const cardImageBuffer = await generateCardImage(firstCard, firstCard.rarityData);
                        attachment = new AttachmentBuilder(cardImageBuffer, { name: `card-${firstCard.id}.png` });
                        embed.setImage(`attachment://card-${firstCard.id}.png`);
                        embed.setColor(firstCard.rarityColor || 0x3498DB);
                    } catch (error) {
                        console.error(`خطأ في توليد صورة الكرت ${currentCards[0].id} للمجموعة:`, error);
                        embed.addFields({ name: "خطأ بالصورة", value: "لم نتمكن من توليد صورة الكرت الأول في هذه الصفحة." });
                    }
                } else {
                    embed.setDescription("لا توجد كروت في هذه الصفحة.");
                }

                return { embed, attachment };
            };

            // دالة لإنشاء أزرار التنقل
            const generateButtons = (page) => {
                return new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId("prev_page")
                            .setLabel("◀️ السابق")
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(page === 0),
                        new ButtonBuilder()
                            .setCustomId("next_page")
                            .setLabel("التالي ▶️")
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(page >= totalPages - 1),
                    );
            };

            const initialContent = await generatePageContent(currentPage);
            const initialButtons = generateButtons(currentPage);

            const messagePayload = {
                embeds: [initialContent.embed],
                components: totalPages > 1 ? [initialButtons] : [],
                files: initialContent.attachment ? [initialContent.attachment] : [],
            };

            const reply = await interaction.editReply(messagePayload);

            if (totalPages <= 1) return; // لا حاجة للمجمع إذا كانت صفحة واحدة

            // مجمع الأزرار للتنقل
            const collector = reply.createMessageComponentCollector({
                componentType: ComponentType.Button,
                time: 120000, // دقيقتان
            });

            collector.on("collect", async (i) => {
                if (i.user.id !== interaction.user.id) {
                    await i.reply({ content: "أنت لا تستطيع التحكم في هذه القائمة.", ephemeral: true });
                    return;
                }

                if (i.customId === "prev_page") {
                    currentPage--;
                } else if (i.customId === "next_page") {
                    currentPage++;
                }

                const updatedContent = await generatePageContent(currentPage);
                const updatedButtons = generateButtons(currentPage);
                const updatedPayload = {
                    embeds: [updatedContent.embed],
                    components: [updatedButtons],
                    files: updatedContent.attachment ? [updatedContent.attachment] : [],
                };
                // مسح الملفات القديمة قبل التحديث لتجنب تراكمها (إذا لزم الأمر)
                updatedPayload.files = updatedPayload.files || [];
                await i.update(updatedPayload);
            });

            collector.on("end", async () => {
                // إزالة الأزرار أو تعطيلها بعد انتهاء الوقت
                const finalContent = await generatePageContent(currentPage);
                const disabledButtons = ActionRowBuilder.from(initialButtons);
                disabledButtons.components.forEach((button) => button.setDisabled(true));
                const finalPayload = {
                    embeds: [finalContent.embed],
                    components: [disabledButtons],
                    files: finalContent.attachment ? [finalContent.attachment] : [],
                };
                // مسح الملفات القديمة قبل التحديث لتجنب تراكمها (إذا لزم الأمر)
                finalPayload.files = finalPayload.files || [];
                await interaction.editReply(finalPayload).catch(console.error);
            });
        } catch (error) {
            console.error("خطأ في أمر /collection:", error);
            await interaction.editReply({ content: "حدث خطأ أثناء محاولة عرض المجموعة.", embeds: [], components: [], files: [] });
        }
    },
};
