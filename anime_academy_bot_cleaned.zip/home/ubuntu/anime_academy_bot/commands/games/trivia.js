const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { getUser, updateUser, updateQuestProgress } = require("../../utils/userDataManager"); // Import updateQuestProgress

const triviaFilePath = path.join(__dirname, "../../games/trivia.json");

// دالة لتحميل أسئلة التريفيا
async function loadTriviaQuestions() {
    try {
        const data = await fs.readJson(triviaFilePath);
        return data.questions || [];
    } catch (error) {
        console.error("خطأ في تحميل أسئلة التريفيا:", error);
        return [];
    }
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName("trivia")
        .setDescription("ابدأ لعبة أسئلة سريعة عن الأنمي!"), // الشرح بالعربي
    async execute(interaction) {
        await interaction.deferReply();
        const questions = await loadTriviaQuestions();

        if (questions.length === 0) {
            await interaction.editReply("عذراً، لا توجد أسئلة متاحة حالياً. حاول مرة أخرى لاحقاً.");
            return;
        }

        // اختيار سؤال عشوائي
        const randomQuestion = questions[Math.floor(Math.random() * questions.length)];
        const { question, options, correctAnswer, difficulty } = randomQuestion;

        // خلط الخيارات
        const shuffledOptions = [...options].sort(() => Math.random() - 0.5);

        // بناء الأزرار
        const buttons = shuffledOptions.map((option, index) => {
            return new ButtonBuilder()
                .setCustomId(`trivia_${index}`)
                .setLabel(option.substring(0, 80))
                .setStyle(ButtonStyle.Secondary);
        });
        const row = new ActionRowBuilder().addComponents(buttons);

        // بناء رسالة Embed للسؤال
        const embed = new EmbedBuilder()
            .setColor(0xFFA500)
            .setTitle("🧠 سؤال تريفيا الأنمي!")
            .setDescription(question)
            .addFields({ name: "الصعوبة", value: difficulty || "غير محدد", inline: true })
            .setFooter({ text: "لديك 30 ثانية للإجابة!" });

        const reply = await interaction.editReply({ embeds: [embed], components: [row] });

        const collector = reply.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 30000, // 30 ثانية
        });

        let answered = false;

        collector.on("collect", async (i) => {
            if (i.user.id !== interaction.user.id) {
                await i.reply({ content: "هذا السؤال موجه للمستخدم الأصلي فقط!", ephemeral: true });
                return;
            }

            answered = true;
            await i.deferUpdate();

            // Remove redundant radix parameter as per eslint suggestion
            const selectedOptionIndex = parseInt(i.customId.split("_")[1]);
            const selectedAnswer = shuffledOptions[selectedOptionIndex];
            const isCorrect = (selectedAnswer === correctAnswer);

            const resultEmbed = EmbedBuilder.from(embed)
                .setColor(isCorrect ? 0x00FF00 : 0xFF0000)
                .setFooter(null);

            let questCompletionMessage = "";

            if (isCorrect) {
                resultEmbed.setDescription(`${question}\n\n**إجابتك:** ${selectedAnswer}\n\n**النتيجة: ✅ صحيح!**`);
                try {
                    // تحديد نقاط الخبرة بناءً على الصعوبة
                    let xpReward;
                    if (difficulty === "صعب") {
                        xpReward = 20;
                    } else if (difficulty === "متوسط") {
                        xpReward = 15;
                    } else {
                        xpReward = 10; // افتراضي
                    }

                    // تحديث نقاط الخبرة الأساسية
                    const currentUserData = await getUser(interaction.user.id, interaction.user.username);
                    await updateUser(interaction.user.id, { xp: currentUserData.xp + xpReward });
                    resultEmbed.addFields({ name: "المكافأة الأساسية", value: `+${xpReward} نقطة خبرة! ✨`, inline: false });

                    // تحديث تقدم المهمة اليومية
                    const questResult = await updateQuestProgress(interaction.user.id, "game_win", "trivia");
                    if (questResult && questResult.completed.length > 0) {
                        questCompletionMessage = `\n🎉 **مهمة مكتملة:** ${questResult.completed[0].name} (+${questResult.xpReward} XP)!`;
                        if (questResult.awardedCard) {
                            questCompletionMessage += ` وحصلت على كرت: **${questResult.awardedCard.name}**!`;
                        }
                    }
                } catch (err) {
                    console.error("خطأ في منح نقاط أو تحديث مهمة التريفيا:", err);
                }
            } else {
                resultEmbed.setDescription(`${question}\n\n**إجابتك:** ${selectedAnswer}\n\n**النتيجة: ❌ خطأ!** الإجابة الصحيحة هي: **${correctAnswer}**`);
            }

            // إضافة رسالة إكمال المهمة إن وجدت
            if (questCompletionMessage) {
                const currentDesc = resultEmbed.data.description || "";
                resultEmbed.setDescription(currentDesc + questCompletionMessage);
            }

            const disabledRow = ActionRowBuilder.from(row);
            disabledRow.components.forEach((button) => button.setDisabled(true));

            await i.editReply({ embeds: [resultEmbed], components: [disabledRow] });
            collector.stop();
        });

        collector.on("end", async (_collected, reason) => { // Rename collected to _collected to satisfy no-unused-vars
            if (reason === "time" && !answered) { // Check if ended due to time and not answered
                const timeoutEmbed = EmbedBuilder.from(embed)
                    .setColor(0xAAAAAA)
                    .setDescription(`${question}\n\n**⏳ انتهى الوقت!** الإجابة الصحيحة كانت: **${correctAnswer}**`)
                    .setFooter(null);

                const disabledRow = ActionRowBuilder.from(row);
                disabledRow.components.forEach((button) => button.setDisabled(true));

                // Use catch for potential errors when editing reply after timeout
                await interaction.editReply({ embeds: [timeoutEmbed], components: [disabledRow] }).catch(console.error);
            }
        });
    },
}; // Removed extra newline at the end
