const fs = require("fs-extra");
const path = require("path");

// --- Constants ---
const DATA_DIR = path.join(__dirname, "../data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const HOUSES_FILE = path.join(DATA_DIR, "houses.json");
const QUESTS_FILE = path.join(DATA_DIR, "daily_quests.json");
const CARDS_FILE = path.join(DATA_DIR, "cards.json");
const EVENTS_FILE = path.join(DATA_DIR, "events.json");

const DEFAULT_USER_DATA = {
    username: "unknown",
    house: null,
    level: "متدرب",
    xp: 0,
    achievements: [],
    collection: [], // Array of { id: cardId, count: number }
    dailyQuestProgress: {}, // { questId: progressCount }
    completedDailyQuests: [], // Array of questId
    lastQuestReset: null, // ISO String
    lastDailyClaim: null, // ISO String
    joinDate: null, // ISO String
};

// --- Data Handling Utilities ---

/**
 * Loads JSON data from a file, creating it with a default value if it doesn't exist.
 * @param {string} filePath - The absolute path to the JSON file.
 * @param {object} defaultValue - The default value to use if the file doesn't exist.
 * @returns {Promise<object>} The loaded data or the default value.
 * @throws {Error} If reading or writing the file fails for reasons other than ENOENT.
 */
async function loadData(filePath, defaultValue = {}) {
    try {
        return await fs.readJson(filePath);
    } catch (error) {
        if (error.code === "ENOENT") {
            console.log(`File ${path.basename(filePath)} not found. Creating with default value.`);
            await saveData(filePath, defaultValue); // Attempt to save the default value
            return defaultValue;
        }
        console.error(`Error loading data from ${filePath}:`, error);
        throw new Error(`Failed to load data from ${path.basename(filePath)}.`); // Re-throw other errors
    }
}

/**
 * Saves JSON data to a file.
 * @param {string} filePath - The absolute path to the JSON file.
 * @param {object} data - The data to save.
 * @returns {Promise<void>}
 * @throws {Error} If writing the file fails.
 */
async function saveData(filePath, data) {
    try {
        await fs.writeJson(filePath, data, { spaces: 2 });
    } catch (error) {
        console.error(`Error saving data to ${filePath}:`, error);
        throw new Error(`Failed to save data to ${path.basename(filePath)}.`); // Re-throw error
    }
}

// --- Event Management ---

/**
 * Gets all currently active events based on start and end times.
 * @returns {Promise<Array<object>>} An array of active event objects.
 */
async function getActiveEvents() {
    try {
        const now = new Date();
        const eventsData = await loadData(EVENTS_FILE, { activeEvents: [] });
        return eventsData.activeEvents.filter((event) => {
            try {
                const startTime = new Date(event.startTime);
                const endTime = new Date(event.endTime);
                return now >= startTime && now <= endTime;
            } catch (dateError) {
                console.error(`Invalid date format for event ${event.id}:`, dateError);
                return false;
            }
        });
    } catch (error) {
        console.error("Failed to load or filter active events:", error);
        return []; // Return empty array on failure
    }
}

// --- User Management ---

/**
 * Retrieves user data, creating a new entry if the user doesn't exist.
 * Also handles daily quest reset logic.
 * @param {string} userId - The Discord user ID.
 * @param {string} username - The Discord username.
 * @returns {Promise<object|null>} The user's data object or null if an error occurs.
 */
async function getUser(userId, username) {
    try {
        const usersData = await loadData(USERS_FILE);
        let userNeedsSave = false;
        const now = new Date();

        // Create new user if they don't exist
        if (!usersData[userId]) {
            console.log(`Creating new user: ${username} (${userId})`);
            usersData[userId] = {
                ...DEFAULT_USER_DATA,
                username,
                joinDate: now.toISOString(),
            };
            userNeedsSave = true;
        }

        // Ensure username is up-to-date
        if (usersData[userId].username !== username) {
            usersData[userId].username = username;
            userNeedsSave = true;
        }

        // Reset daily quests if it's a new day
        const lastReset = usersData[userId].lastQuestReset ? new Date(usersData[userId].lastQuestReset) : null;
        if (!lastReset || now.toDateString() !== lastReset.toDateString()) {
            console.log(`Resetting daily quests for user ${userId}`);
            usersData[userId].dailyQuestProgress = {};
            usersData[userId].completedDailyQuests = [];
            usersData[userId].lastQuestReset = now.toISOString();
            userNeedsSave = true;
        }

        if (userNeedsSave) {
            await saveData(USERS_FILE, usersData);
        }

        return usersData[userId];
    } catch (error) {
        console.error(`Error getting user data for ${userId}:`, error);
        return null; // Return null on error
    }
}

/**
 * Updates a user's data with new values, applying event modifiers.
 * @param {string} userId - The Discord user ID.
 * @param {object} newData - An object containing the data fields to update.
 * @param {Array<object>} [activeEvents=[]] - Optional array of active events.
 * @returns {Promise<boolean>} True if update was successful, false otherwise.
 */
async function updateUser(userId, newData, activeEvents = []) {
    try {
        const usersData = await loadData(USERS_FILE);
        if (!usersData[userId]) {
            console.warn(`Attempted to update non-existent user: ${userId}`);
            return false;
        }

        const oldData = { ...usersData[userId] };
        const mergedData = { ...oldData, ...newData }; // Merge old and new data
        const oldXP = oldData.xp || 0;

        // Apply XP multiplier from events if XP is being updated
        if ("xp" in newData) {
            const xpEvent = activeEvents.find((event) => event.type === "xp_multiplier");
            if (xpEvent) {
                const xpMultiplier = xpEvent.multiplier || 1;
                const xpGained = (newData.xp - oldXP);
                if (xpGained > 0) {
                    const bonusXP = xpGained * (xpMultiplier - 1);
                    mergedData.xp = oldXP + xpGained + bonusXP; // Apply multiplier to the gained XP
                    console.log(`Applied XP multiplier (${xpMultiplier}x) from event ${xpEvent.id} to user ${userId}. Gained: ${xpGained}, Bonus: ${bonusXP}`);
                }
            }
        }

        const finalXP = mergedData.xp || 0;
        const xpGainedActual = finalXP - oldXP;

        // Update house points based on actual XP gained
        if (xpGainedActual > 0 && mergedData.house) {
            await _updateHousePointsOnXPChange(mergedData.house, xpGainedActual);
        }

        // Handle house change logic
        if ("house" in newData && newData.house !== oldData.house) {
            await _updateHouseMembership(userId, oldData.house, newData.house);
        }

        // Update user data in the main object
        usersData[userId] = mergedData;
        await saveData(USERS_FILE, usersData);
        return true;
    } catch (error) {
        console.error(`Error updating user data for ${userId}:`, error);
        return false;
    }
}

// --- House Management ---

/**
 * Loads all house data.
 * @returns {Promise<object>} The house data object.
 */
async function loadHousesData() {
    try {
        return await loadData(HOUSES_FILE);
    } catch (error) {
        console.error("Failed to load houses data:", error);
        return {}; // Return empty object on failure
    }
}

/**
 * Updates the points for a specific house.
 * @param {string} houseId - The ID of the house to update.
 * @param {number} pointsToAdd - The number of points to add (can be negative).
 * @returns {Promise<void>}
 */
async function updateHousePoints(houseId, pointsToAdd) {
    if (!houseId || pointsToAdd === 0) return;
    try {
        const housesData = await loadHousesData();
        if (housesData[houseId]) {
            housesData[houseId].points = (housesData[houseId].points || 0) + pointsToAdd;
            await saveData(HOUSES_FILE, housesData);
            console.log(`Updated points for house ${houseId} by ${pointsToAdd}. New total: ${housesData[houseId].points}`);
        } else {
            console.warn(`Attempted to update points for non-existent house: ${houseId}`);
        }
    } catch (error) {
        console.error(`Error updating points for house ${houseId}:`, error);
    }
}

/**
 * Internal helper to update house points based on XP gained by a member.
 * @param {string} houseId - The house ID.
 * @param {number} xpGained - The amount of XP gained.
 * @returns {Promise<void>}
 */
async function _updateHousePointsOnXPChange(houseId, xpGained) {
    const pointsFromXP = Math.floor(xpGained / 50); // Example: 1 point per 50 XP
    if (pointsFromXP > 0) {
        await updateHousePoints(houseId, pointsFromXP);
    }
}

/**
 * Internal helper to update house membership when a user changes houses.
 * @param {string} userId - The user ID.
 * @param {string|null} oldHouseId - The user's previous house ID.
 * @param {string|null} newHouseId - The user's new house ID.
 * @returns {Promise<void>}
 */
async function _updateHouseMembership(userId, oldHouseId, newHouseId) {
    try {
        const housesData = await loadHousesData();
        // Remove from old house
        if (oldHouseId && housesData[oldHouseId]?.members) {
            housesData[oldHouseId].members = housesData[oldHouseId].members.filter((id) => id !== userId);
        }
        // Add to new house
        if (newHouseId && housesData[newHouseId]) {
            if (!housesData[newHouseId].members) {
                housesData[newHouseId].members = [];
            }
            if (!housesData[newHouseId].members.includes(userId)) {
                housesData[newHouseId].members.push(userId);
            }
        }
        await saveData(HOUSES_FILE, housesData);
    } catch (error) {
        console.error(`Error updating house membership for user ${userId}:`, error);
    }
}

// --- Card Management ---

/**
 * Selects a random card based on rarity drop rates, considering active events.
 * @param {Array<object>} [activeEvents=[]] - Optional array of active events.
 * @returns {Promise<object|null>} The chosen card object (including rarityData) or null if error/no cards.
 */
async function getRandomCard(activeEvents = []) {
    try {
        const cardsData = await loadData(CARDS_FILE);
        if (!cardsData || !Array.isArray(cardsData.cards) || !cardsData.rarities || cardsData.cards.length === 0) {
            console.error("Invalid or empty cards data file.");
            return null;
        }

        // Deep copy rarities to apply boosts without modifying the original data
        const effectiveRarities = JSON.parse(JSON.stringify(cardsData.rarities));

        // Apply card drop boost from events
        const boostEvent = activeEvents.find((event) => event.type === "card_drop_boost");
        if (boostEvent?.rarityBoost) {
            console.log(`Applying card drop boost from event ${boostEvent.id}`);
            for (const rarityKey in boostEvent.rarityBoost) {
                if (effectiveRarities[rarityKey]) {
                    effectiveRarities[rarityKey].dropRate = (effectiveRarities[rarityKey].dropRate || 0) * (boostEvent.rarityBoost[rarityKey] || 1);
                }
            }
        }

        const totalDropRate = Object.values(effectiveRarities).reduce((sum, r) => sum + (r.dropRate || 0), 0);
        if (totalDropRate <= 0) {
            console.warn("Total card drop rate is zero or negative after applying boosts.");
            return null; // Cannot select a card if total rate is zero
        }

        let random = Math.random() * totalDropRate;
        let selectedRarityKey = null;

        // Sort rarities by order (descending) to prioritize higher rarities in case of ties
        const sortedRarityKeys = Object.keys(effectiveRarities).sort((a, b) => (effectiveRarities[b].order || 0) - (effectiveRarities[a].order || 0));

        for (const rarityKey of sortedRarityKeys) {
            const rate = effectiveRarities[rarityKey].dropRate || 0;
            if (random < rate) {
                selectedRarityKey = rarityKey;
                break;
            }
            random -= rate;
        }

        // Fallback to common if something went wrong (should ideally not happen with positive totalDropRate)
        if (!selectedRarityKey) {
            console.warn("Could not determine selected rarity, falling back to common.");
            selectedRarityKey = Object.keys(effectiveRarities).find((k) => k === "common") || sortedRarityKeys[sortedRarityKeys.length - 1];
            if (!selectedRarityKey) return null; // No rarities defined at all
        }

        const cardsOfSelectedRarity = cardsData.cards.filter((card) => card.rarity === selectedRarityKey);

        if (cardsOfSelectedRarity.length === 0) {
            console.warn(`No cards found for selected rarity '${selectedRarityKey}'. Trying fallback to common.`);
            // Fallback to common cards if the selected rarity has no cards
            const commonCards = cardsData.cards.filter((card) => card.rarity === "common");
            if (commonCards.length === 0) {
                console.error("No common cards available for fallback.");
                return null;
            }
            const chosenCard = commonCards[Math.floor(Math.random() * commonCards.length)];
            return { ...chosenCard, rarityData: cardsData.rarities.common }; // Use original rarity data
        }

        const chosenCard = cardsOfSelectedRarity[Math.floor(Math.random() * cardsOfSelectedRarity.length)];
        return { ...chosenCard, rarityData: cardsData.rarities[selectedRarityKey] }; // Use original rarity data
    } catch (error) {
        console.error("Error selecting random card:", error);
        return null;
    }
}

// --- Quest Management ---

/**
 * Updates the user's progress for daily quests based on an action.
 * @param {string} userId - The user ID.
 * @param {'command_usage' | 'game_win'} questType - The type of action triggering the progress.
 * @param {string} target - The specific command name or game name.
 * @param {number} [amount=1] - The amount of progress to add.
 * @returns {Promise<object|null>} An object containing completed quests and rewards, or null on error.
 */
async function updateQuestProgress(userId, questType, target, amount = 1) {
    try {
        const userData = await getUser(userId, "unknown"); // Username might not be needed here
        if (!userData) return null;

        const usersData = await loadData(USERS_FILE);
        const currentUserData = usersData[userId]; // Get the mutable reference

        const questsData = await loadData(QUESTS_FILE, { quests: [] });
        const activeEvents = await getActiveEvents(); // Get active events for potential rewards

        // Find quests applicable to this action that haven't been completed today
        const applicableQuests = questsData.quests.filter((q) => !currentUserData.completedDailyQuests.includes(q.id)
            && q.type === questType
            && (
                (questType === "command_usage" && q.targetCommand === target)
                || (questType === "game_win" && q.targetGame === target)
                // Add other quest type checks here
            ));

        if (applicableQuests.length === 0) {
            return { completed: [], xpReward: 0, awardedCard: null }; // No applicable quests to update
        }

        const questsCompletedNow = [];
        let totalXpRewardFromQuests = 0;
        let grantExtraCard = false;
        let pointsFromQuests = 0;
        let userModified = false;

        for (const quest of applicableQuests) {
            const progress = currentUserData.dailyQuestProgress[quest.id] || 0;
            const newProgress = progress + amount;
            currentUserData.dailyQuestProgress[quest.id] = newProgress;
            userModified = true;

            if (newProgress >= (quest.requiredCount || 1)) {
                console.log(`User ${userId} completed quest ${quest.id}: ${quest.name}`);
                currentUserData.completedDailyQuests.push(quest.id);
                questsCompletedNow.push(quest);
                totalXpRewardFromQuests += quest.reward?.xp || 0;
                pointsFromQuests += 5; // Example: 5 house points per quest
                if (quest.reward?.cardChance && Math.random() < quest.reward.cardChance) {
                    grantExtraCard = true;
                }
            }
        }

        if (questsCompletedNow.length === 0 && !userModified) {
            return { completed: [], xpReward: 0, awardedCard: null }; // No progress made or quests completed
        }

        // Apply XP multiplier event to quest rewards
        let finalXpReward = totalXpRewardFromQuests;
        const xpEvent = activeEvents.find((event) => event.type === "xp_multiplier");
        if (xpEvent && finalXpReward > 0) {
            const multiplier = xpEvent.multiplier || 1;
            finalXpReward = Math.floor(finalXpReward * multiplier); // Apply multiplier
            console.log(`Applied XP multiplier (${multiplier}x) from event ${xpEvent.id} to quest rewards for user ${userId}.`);
        }

        // Add XP reward to user data
        if (finalXpReward > 0) {
            currentUserData.xp = (currentUserData.xp || 0) + finalXpReward;
            userModified = true;
        }

        // Grant extra card if applicable
        let awardedCardData = null;
        if (grantExtraCard) {
            const randomCard = await getRandomCard(activeEvents); // Pass active events for potential boost
            if (randomCard) {
                awardedCardData = { name: randomCard.name, rarity: randomCard.rarityData?.name || randomCard.rarity, id: randomCard.id, rarityData: randomCard.rarityData };
                const collection = currentUserData.collection || [];
                const existingCardIndex = collection.findIndex((c) => c.id === randomCard.id);
                if (existingCardIndex > -1) {
                    collection[existingCardIndex].count = (collection[existingCardIndex].count || 1) + 1;
                } else {
                    collection.push({ id: randomCard.id, count: 1 });
                }
                currentUserData.collection = collection;
                userModified = true;
                console.log(`User ${userId} received bonus card ${randomCard.id} from quest completion.`);
            }
        }

        // Update house points from completed quests
        if (pointsFromQuests > 0 && currentUserData.house) {
            await updateHousePoints(currentUserData.house, pointsFromQuests);
        }

        // Save user data if modified
        if (userModified) {
            await saveData(USERS_FILE, usersData);
        }

        return {
            completed: questsCompletedNow,
            xpReward: finalXpReward,
            awardedCard: awardedCardData,
        };
    } catch (error) {
        console.error(`Error updating quest progress for user ${userId}:`, error);
        return null;
    }
}

module.exports = {
    getUser,
    updateUser,
    loadHousesData,
    updateHousePoints,
    updateQuestProgress,
    getActiveEvents,
    getRandomCard, // Export the consolidated function
    // Removed getRandomCardInternal as it's now consolidated into getRandomCard
};
