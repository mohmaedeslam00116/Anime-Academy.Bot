const { Client, GatewayIntentBits, Collection, Events } = require("discord.js");
const fs = require("fs-extra");
const path = require("path");
const { token } = require("./config.json"); // Assuming config.json is in the root

// --- Client Initialization ---
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages, // Needed for message collector in guess game
        GatewayIntentBits.GuildMembers, // Potentially needed for user data
        // Add more intents if required by future features
    ],
});

// --- Configuration and Data ---
client.config = require("./config.json");
// Data like users.json is managed by userDataManager.js

// --- Command Handling ---
client.commands = new Collection();
const foldersPath = path.join(__dirname, "commands");
const commandFolders = fs.readdirSync(foldersPath);

console.log("🔄️ Loading commands...");
for (const folder of commandFolders) {
    const commandsPath = path.join(foldersPath, folder);
    // Check if it's a directory before reading files
    if (fs.lstatSync(commandsPath).isDirectory()) {
        const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith(".js"));
        for (const file of commandFiles) {
            const filePath = path.join(commandsPath, file);
            try {
                const command = require(filePath);
                // Set a new item in the Collection with the key as the command name and the value as the exported module
                if ("data" in command && "execute" in command) {
                    client.commands.set(command.data.name, command);
                    console.log(`[COMMAND LOADED] ${folder}/${file}`);
                } else {
                    console.warn(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
                }
            } catch (error) {
                console.error(`[ERROR] Failed to load command at ${filePath}:`, error);
            }
        }
    }
}
console.log(`✅ Successfully loaded ${client.commands.size} commands.`);

// --- Event Handling ---

// Ready Event
client.once(Events.ClientReady, (readyClient) => {
    console.log(`✅ Ready! Logged in as ${readyClient.user.tag}`);
    // Set bot status
    readyClient.user.setActivity("أكاديمية عالم الأنمي", { type: "WATCHING" });

    // Register slash commands (important for them to appear in Discord)
    // This should ideally be a separate script (deploy-commands.js) run once
    // But for simplicity, we can do it here on ready (might be slow on many guilds)
    // Consider moving this to a dedicated deploy script later
    const commandsData = client.commands.map((cmd) => cmd.data.toJSON());
    readyClient.application.commands.set(commandsData)
        .then(() => console.log("✅ Successfully registered application commands globally."))
        .catch(console.error);
});

// Interaction Create Event (Handles Slash Commands and Button Interactions)
client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isChatInputCommand()) {
        const command = interaction.client.commands.get(interaction.commandName);

        if (!command) {
            console.error(`No command matching ${interaction.commandName} was found.`);
            try {
                await interaction.reply({ content: "❌ عذراً، لم يتم العثور على هذا الأمر!", ephemeral: true });
            } catch (err) {
                console.error("Error replying to unknown command interaction:", err);
            }
            return;
        }

        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(`Error executing command ${interaction.commandName}:`, error);
            const errorMessage = "حدث خطأ أثناء تنفيذ هذا الأمر! 😥";
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: errorMessage, ephemeral: true }).catch(console.error);
            } else {
                await interaction.reply({ content: errorMessage, ephemeral: true }).catch(console.error);
            }
        }
    } else if (interaction.isButton()) {
        // Handle button interactions (e.g., from trivia game)
        // You might want a more sophisticated handler if you have many button types
        console.log(`Button interaction received: ${interaction.customId}`);
        // The trivia command itself handles its button collection, so no specific code needed here unless
        // you want a centralized button handler.
    }
    // Add handlers for other interaction types (Select Menus, Modals) if needed
});

// --- Login ---
client.login(token).catch((err) => {
    console.error("❌ Login Error:", err);
    process.exit(1); // Exit if login fails
});

// --- Optional: Graceful Shutdown ---
process.on("SIGINT", () => {
    console.log("🔌 Shutting down bot...");
    client.destroy();
    process.exit(0);
});
